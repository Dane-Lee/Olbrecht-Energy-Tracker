export interface Athlete {
  id: string;
  name: string;
  email: string;
  dateOfBirth: string;
  gender: 'male' | 'female';
  specialtyDistance: number; // in meters
  personalBests: Record<number, number>; // distance -> time in seconds
  physiologicalProfile: PhysiologicalProfile;
  createdAt: string;
  updatedAt: string;
}

export interface PhysiologicalProfile {
  // These would typically come from the companion swim test app
  criticalVelocity: number; // m/s
  anaerobicCapacity: number; // meters
  aerobicPower: number; // watts
  lactateThreshold: number; // mmol/L
  maxLactate: number; // mmol/L
  recoveryRate: number; // lactate clearance rate
  // Default values for when companion app data isn't available
  estimatedVO2Max?: number;
  restingHeartRate?: number;
  maxHeartRate?: number;
}