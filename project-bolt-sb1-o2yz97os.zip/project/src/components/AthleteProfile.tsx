import React, { useState } from 'react';
import { User, Calendar, Target, Activity } from 'lucide-react';
import { Athlete, PhysiologicalProfile } from '../types/athlete';

interface AthleteProfileProps {
  athlete: Athlete;
  onUpdateProfile: (profile: PhysiologicalProfile) => void;
}

export const AthleteProfile: React.FC<AthleteProfileProps> = ({ athlete, onUpdateProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [profile, setProfile] = useState(athlete.physiologicalProfile);

  const handleSave = () => {
    onUpdateProfile(profile);
    setIsEditing(false);
  };

  const calculateAge = (dateOfBirth: string): number => {
    const today = new Date();
    const birth = new Date(dateOfBirth);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{athlete.name}</h2>
            <p className="text-gray-600">{athlete.email}</p>
          </div>
        </div>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="flex items-center space-x-3">
          <Calendar className="w-5 h-5 text-blue-600" />
          <div>
            <p className="text-sm text-gray-600">Age</p>
            <p className="font-semibold">{calculateAge(athlete.dateOfBirth)} years</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Target className="w-5 h-5 text-blue-600" />
          <div>
            <p className="text-sm text-gray-600">Specialty</p>
            <p className="font-semibold">{athlete.specialtyDistance}m</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Activity className="w-5 h-5 text-blue-600" />
          <div>
            <p className="text-sm text-gray-600">Gender</p>
            <p className="font-semibold capitalize">{athlete.gender}</p>
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold mb-4">Physiological Profile</h3>
        
        {isEditing ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Critical Velocity (m/s)
              </label>
              <input
                type="number"
                step="0.01"
                value={profile.criticalVelocity}
                onChange={(e) => setProfile({ ...profile, criticalVelocity: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Anaerobic Capacity (m)
              </label>
              <input
                type="number"
                step="1"
                value={profile.anaerobicCapacity}
                onChange={(e) => setProfile({ ...profile, anaerobicCapacity: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Aerobic Power (W)
              </label>
              <input
                type="number"
                step="1"
                value={profile.aerobicPower}
                onChange={(e) => setProfile({ ...profile, aerobicPower: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lactate Threshold (mmol/L)
              </label>
              <input
                type="number"
                step="0.1"
                value={profile.lactateThreshold}
                onChange={(e) => setProfile({ ...profile, lactateThreshold: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="md:col-span-2 flex justify-end space-x-3">
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-600 font-medium">Critical Velocity</p>
              <p className="text-2xl font-bold text-blue-900">{profile.criticalVelocity.toFixed(2)} m/s</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-green-600 font-medium">Anaerobic Capacity</p>
              <p className="text-2xl font-bold text-green-900">{profile.anaerobicCapacity.toFixed(0)} m</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-purple-600 font-medium">Aerobic Power</p>
              <p className="text-2xl font-bold text-purple-900">{profile.aerobicPower.toFixed(0)} W</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <p className="text-sm text-orange-600 font-medium">Lactate Threshold</p>
              <p className="text-2xl font-bold text-orange-900">{profile.lactateThreshold.toFixed(1)} mmol/L</p>
            </div>
          </div>
        )}
      </div>

      <div className="border-t pt-6 mt-6">
        <h3 className="text-lg font-semibold mb-4">Personal Bests</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(athlete.personalBests).map(([distance, time]) => (
            <div key={distance} className="bg-gray-50 p-3 rounded-lg">
              <p className="text-sm text-gray-600">{distance}m</p>
              <p className="font-semibold">
                {Math.floor(time / 60)}:{(time % 60).toFixed(2).padStart(5, '0')}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};