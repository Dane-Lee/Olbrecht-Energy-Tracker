import React from 'react';
import { Calendar, Clock, Target, Activity, TrendingUp } from 'lucide-react';
import { TrainingSession } from '../types/training';
import { EnergySystemChart } from './EnergySystemChart';
import { formatTime } from '../utils/olbrechtCalculations';

interface SessionListProps {
  sessions: TrainingSession[];
  onSelectSession: (session: TrainingSession) => void;
}

export const SessionList: React.FC<SessionListProps> = ({ sessions, onSelectSession }) => {
  const sortedSessions = [...sessions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const getSessionTypeColor = (type: string) => {
    switch (type) {
      case 'competition': return 'bg-red-100 text-red-800';
      case 'test': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity >= 1.1) return 'text-red-600';
    if (intensity >= 1.0) return 'text-orange-600';
    if (intensity >= 0.9) return 'text-yellow-600';
    return 'text-green-600';
  };

  return (
    <div className="space-y-4">
      {sortedSessions.length === 0 ? (
        <div className="text-center py-12">
          <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No training sessions yet</h3>
          <p className="text-gray-600">Start by adding your first training session to track your progress.</p>
        </div>
      ) : (
        sortedSessions.map((session) => (
          <div
            key={session.id}
            onClick={() => onSelectSession(session)}
            className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">
                    {new Date(session.date).toLocaleDateString()}
                  </span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSessionTypeColor(session.sessionType)}`}>
                  {session.sessionType.charAt(0).toUpperCase() + session.sessionType.slice(1)}
                </span>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Training Load</p>
                <p className="font-semibold text-lg">{session.trainingLoad.trainingStressScore.toFixed(0)} TSS</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4 text-blue-600" />
                <div>
                  <p className="text-xs text-gray-600">Distance</p>
                  <p className="font-semibold">{session.totalDistance.toLocaleString()}m</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-green-600" />
                <div>
                  <p className="text-xs text-gray-600">Time</p>
                  <p className="font-semibold">{formatTime(session.totalTime)}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-purple-600" />
                <div>
                  <p className="text-xs text-gray-600">Intensity</p>
                  <p className={`font-semibold ${getIntensityColor(session.averageIntensity)}`}>
                    {(session.averageIntensity * 100).toFixed(0)}% CV
                  </p>
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600">Recovery</p>
                <p className="font-semibold">{session.trainingLoad.recoveryTime}h</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Sets Overview</h4>
                <div className="space-y-1">
                  {session.sets.slice(0, 3).map((set, index) => (
                    <div key={set.id} className="text-sm text-gray-600">
                      {set.repetitions}x{set.distance}m @ {formatTime(set.times[0])}
                      {set.times.length > 1 && ` (avg)`}
                    </div>
                  ))}
                  {session.sets.length > 3 && (
                    <div className="text-sm text-gray-500">
                      +{session.sets.length - 3} more sets
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-center">
                <EnergySystemChart 
                  energyContribution={session.energySystemContribution} 
                  size="small"
                />
              </div>
            </div>

            {session.notes && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-sm text-gray-600">{session.notes}</p>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};