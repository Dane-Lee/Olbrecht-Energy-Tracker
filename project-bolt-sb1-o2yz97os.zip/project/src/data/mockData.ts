import { Athlete } from '../types/athlete';
import { TrainingSession } from '../types/training';

// Mock athlete data for demonstration
export const mockAthlete: Athlete = {
  id: 'athlete-1',
  name: 'Sarah Johnson',
  email: 'sarah.johnson@email.com',
  dateOfBirth: '1995-03-15',
  gender: 'female',
  specialtyDistance: 200,
  personalBests: {
    50: 24.5,
    100: 52.8,
    200: 115.2,
    400: 245.6,
    800: 520.3,
    1500: 1020.5
  },
  physiologicalProfile: {
    criticalVelocity: 1.45, // m/s (approximately 1:09/100m pace)
    anaerobicCapacity: 25.0, // meters
    aerobicPower: 280, // watts
    lactateThreshold: 4.0, // mmol/L
    maxLactate: 12.0, // mmol/L
    recoveryRate: 0.8, // lactate clearance rate
    estimatedVO2Max: 55,
    restingHeartRate: 48,
    maxHeartRate: 195
  },
  createdAt: '2024-01-01T00:00:00Z',
  updatedAt: '2024-01-15T00:00:00Z'
};

// Mock training sessions
export const mockSessions: TrainingSession[] = [
  {
    id: 'session-1',
    athleteId: 'athlete-1',
    date: '2024-01-15',
    sessionType: 'training',
    sets: [
      {
        id: 'set-1',
        distance: 400,
        repetitions: 1,
        times: [280.5],
        restInterval: 0,
        strokeRate: [32],
        heartRate: [165],
        perceivedExertion: [7]
      },
      {
        id: 'set-2',
        distance: 100,
        repetitions: 4,
        times: [65.2, 66.1, 66.8, 67.5],
        restInterval: 60,
        strokeRate: [38, 38, 37, 36],
        heartRate: [175, 178, 180, 182],
        perceivedExertion: [8, 8, 9, 9]
      },
      {
        id: 'set-3',
        distance: 50,
        repetitions: 8,
        times: [28.5, 28.8, 29.1, 29.4, 29.8, 30.2, 30.6, 31.0],
        restInterval: 30,
        strokeRate: [42, 42, 41, 41, 40, 40, 39, 38],
        heartRate: [185, 187, 188, 189, 190, 191, 192, 193],
        perceivedExertion: [9, 9, 9, 10, 10, 10, 10, 10]
      }
    ],
    totalDistance: 1200,
    totalTime: 1560.4,
    averageIntensity: 1.08,
    energySystemContribution: {
      aerobic: 65.2,
      anaerobicLactic: 28.5,
      anaerobicAlactic: 6.3,
      totalEnergyExpenditure: 145.8
    },
    trainingLoad: {
      volume: 1200,
      intensity: 1.08,
      trainingStressScore: 85.4,
      monotony: 1.2,
      strain: 102.5,
      recoveryTime: 18
    },
    notes: 'Good session, felt strong on the 100s. Last 50s were tough but maintained technique.',
    createdAt: '2024-01-15T10:30:00Z'
  },
  {
    id: 'session-2',
    athleteId: 'athlete-1',
    date: '2024-01-13',
    sessionType: 'training',
    sets: [
      {
        id: 'set-1',
        distance: 800,
        repetitions: 1,
        times: [580.2],
        restInterval: 0,
        strokeRate: [30],
        heartRate: [155],
        perceivedExertion: [6]
      },
      {
        id: 'set-2',
        distance: 200,
        repetitions: 3,
        times: [135.5, 136.8, 138.2],
        restInterval: 90,
        strokeRate: [35, 34, 33],
        heartRate: [170, 172, 174],
        perceivedExertion: [7, 8, 8]
      }
    ],
    totalDistance: 1400,
    totalTime: 1090.7,
    averageIntensity: 0.95,
    energySystemContribution: {
      aerobic: 78.5,
      anaerobicLactic: 18.2,
      anaerobicAlactic: 3.3,
      totalEnergyExpenditure: 125.6
    },
    trainingLoad: {
      volume: 1400,
      intensity: 0.95,
      trainingStressScore: 65.2,
      monotony: 1.1,
      strain: 71.7,
      recoveryTime: 14
    },
    notes: 'Aerobic base session. Focused on maintaining steady pace and good stroke technique.',
    createdAt: '2024-01-13T09:15:00Z'
  },
  {
    id: 'session-3',
    athleteId: 'athlete-1',
    date: '2024-01-11',
    sessionType: 'test',
    sets: [
      {
        id: 'set-1',
        distance: 200,
        repetitions: 1,
        times: [115.2],
        restInterval: 0,
        strokeRate: [40],
        heartRate: [192],
        perceivedExertion: [10],
        lactateValues: [11.5]
      }
    ],
    totalDistance: 200,
    totalTime: 115.2,
    averageIntensity: 1.25,
    energySystemContribution: {
      aerobic: 45.8,
      anaerobicLactic: 42.5,
      anaerobicAlactic: 11.7,
      totalEnergyExpenditure: 35.2
    },
    trainingLoad: {
      volume: 200,
      intensity: 1.25,
      trainingStressScore: 25.8,
      monotony: 1.0,
      strain: 25.8,
      recoveryTime: 8
    },
    notes: 'Personal best! Great race simulation. High lactate confirms good anaerobic contribution.',
    createdAt: '2024-01-11T16:45:00Z'
  }
];