import React, { useState } from 'react';
import { Activity, Plus, User, BarChart3, Calendar } from 'lucide-react';
import { AthleteProfile } from './components/AthleteProfile';
import { TrainingSessionForm } from './components/TrainingSessionForm';
import { SessionList } from './components/SessionList';
import { PerformanceDashboard } from './components/PerformanceDashboard';
import { EnergySystemChart } from './components/EnergySystemChart';
import { useLocalStorage } from './hooks/useLocalStorage';
import { mockAthlete, mockSessions } from './data/mockData';
import { Athlete, PhysiologicalProfile } from './types/athlete';
import { TrainingSession } from './types/training';

type View = 'dashboard' | 'sessions' | 'profile' | 'add-session';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [athlete, setAthlete] = useLocalStorage<Athlete>('athlete', mockAthlete);
  const [sessions, setSessions] = useLocalStorage<TrainingSession[]>('sessions', mockSessions);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);

  const handleUpdateProfile = (profile: PhysiologicalProfile) => {
    setAthlete({ ...athlete, physiologicalProfile: profile, updatedAt: new Date().toISOString() });
  };

  const handleSaveSession = (sessionData: Omit<TrainingSession, 'id' | 'createdAt'>) => {
    const newSession: TrainingSession = {
      ...sessionData,
      id: `session-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setSessions([...sessions, newSession]);
    setCurrentView('sessions');
  };

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'sessions', label: 'Sessions', icon: Calendar },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Olbrecht Energy Tracker</h1>
                <p className="text-sm text-gray-600">Elite Swimming Performance Analysis</p>
              </div>
            </div>
            
            <button
              onClick={() => setCurrentView('add-session')}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Session</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:w-64">
            <nav className="bg-white rounded-xl shadow-sm p-4">
              <ul className="space-y-2">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => setCurrentView(item.id as View)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          currentView === item.id
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </nav>

            {/* Quick Stats */}
            <div className="mt-6 bg-white rounded-xl shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Quick Stats</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Total Sessions</p>
                  <p className="text-lg font-bold text-blue-600">{sessions.length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">This Week</p>
                  <p className="text-lg font-bold text-green-600">
                    {sessions.filter(s => {
                      const sessionDate = new Date(s.date);
                      const weekAgo = new Date();
                      weekAgo.setDate(weekAgo.getDate() - 7);
                      return sessionDate >= weekAgo;
                    }).length}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Volume</p>
                  <p className="text-lg font-bold text-purple-600">
                    {(sessions.reduce((sum, s) => sum + s.totalDistance, 0) / 1000).toFixed(1)}km
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {currentView === 'dashboard' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">Performance Dashboard</h2>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded-lg">Week</button>
                    <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">Month</button>
                    <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-lg">Season</button>
                  </div>
                </div>
                <PerformanceDashboard sessions={sessions} timeframe="week" />
              </div>
            )}

            {currentView === 'sessions' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">Training Sessions</h2>
                  <button
                    onClick={() => setCurrentView('add-session')}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Session</span>
                  </button>
                </div>
                <SessionList sessions={sessions} onSelectSession={setSelectedSession} />
              </div>
            )}

            {currentView === 'profile' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Athlete Profile</h2>
                <AthleteProfile athlete={athlete} onUpdateProfile={handleUpdateProfile} />
              </div>
            )}

            {currentView === 'add-session' && (
              <div className="space-y-6">
                <TrainingSessionForm
                  athleteId={athlete.id}
                  profile={athlete.physiologicalProfile}
                  onSave={handleSaveSession}
                  onCancel={() => setCurrentView('sessions')}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Session Detail Modal */}
      {selectedSession && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  Session Details - {new Date(selectedSession.date).toLocaleDateString()}
                </h2>
                <button
                  onClick={() => setSelectedSession(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ✕
                </button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Session Overview</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Type:</span>
                      <span className="font-medium capitalize">{selectedSession.sessionType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Distance:</span>
                      <span className="font-medium">{selectedSession.totalDistance}m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Time:</span>
                      <span className="font-medium">
                        {Math.floor(selectedSession.totalTime / 60)}:{(selectedSession.totalTime % 60).toFixed(0).padStart(2, '0')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Average Intensity:</span>
                      <span className="font-medium">{(selectedSession.averageIntensity * 100).toFixed(0)}% CV</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Training Load:</span>
                      <span className="font-medium">{selectedSession.trainingLoad.trainingStressScore.toFixed(0)} TSS</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <EnergySystemChart 
                    energyContribution={selectedSession.energySystemContribution} 
                    size="medium"
                  />
                </div>
              </div>

              {selectedSession.notes && (
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Notes</h4>
                  <p className="text-gray-700">{selectedSession.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;