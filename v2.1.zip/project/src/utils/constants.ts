/**
 * Application-wide constants and configuration values
 */

// Energy System Thresholds (in seconds)
export const ENERGY_SYSTEM_THRESHOLDS = {
  VERY_SHORT_DURATION: 10,        // < 10s: primarily phosphocreatine
  SHORT_DURATION: 60,              // < 60s: mixed anaerobic
  MEDIUM_DURATION: 300,            // < 5min: transitioning to aerobic
  // > 5min: primarily aerobic
} as const;

// Energy System Percentages
export const ENERGY_SYSTEM_PERCENTAGES = {
  // Very short duration (< 10s)
  VERY_SHORT_ALACTIC_BASE: 85,
  VERY_SHORT_ALACTIC_MAX: 95,
  VERY_SHORT_LACTIC_MIN: 5,
  VERY_SHORT_LACTIC_BASE: 15,

  // Short duration (10-60s)
  SHORT_ALACTIC_MIN: 10,
  SHORT_ALACTIC_BASE: 50,
  SHORT_LACTIC_BASE: 30,
  SHORT_LACTIC_MAX: 70,
  SHORT_AEROBIC_MIN: 20,

  // Medium duration (60-300s)
  MEDIUM_ALACTIC_MIN: 5,
  MEDIUM_ALACTIC_BASE: 15,
  MEDIUM_LACTIC_MIN: 15,
  MEDIUM_LACTIC_BASE: 60,

  // Long duration (> 300s)
  LONG_ALACTIC_MIN: 2,
  LONG_ALACTIC_BASE: 8,
  LONG_LACTIC_MIN: 8,
  LONG_LACTIC_BASE: 25,
} as const;

// Intensity Zones (percentage of Critical Velocity)
export const INTENSITY_ZONES = {
  RECOVERY: {
    name: 'Recovery',
    max: 70,
    description: 'Active recovery and easy aerobic work',
    lactateMin: 1.0,
    lactateMax: 2.0,
  },
  AEROBIC_BASE: {
    name: 'Aerobic Base',
    min: 70,
    max: 85,
    description: 'Aerobic capacity development',
    lactateMin: 2.0,
    lactateMax: 3.0,
  },
  THRESHOLD: {
    name: 'Threshold',
    min: 85,
    max: 100,
    description: 'Lactate threshold training',
    lactateMin: 3.0,
    lactateMax: 4.0,
  },
  VO2_MAX: {
    name: 'VO2 Max',
    min: 100,
    max: 115,
    description: 'Maximal aerobic power',
    lactateMin: 4.0,
    lactateMax: 8.0,
  },
  NEUROMUSCULAR: {
    name: 'Neuromuscular',
    min: 115,
    description: 'Speed and power development',
    lactateMin: 8.0,
    lactateMax: 15.0,
  },
} as const;

// Intensity Factor Thresholds
export const INTENSITY_FACTORS = {
  HIGH: 1.1,           // > 110% CV
  THRESHOLD: 1.0,      // 100% CV
  MODERATE: 0.9,       // 90% CV
} as const;

// Training Load Calculations
export const TRAINING_LOAD = {
  BASE_METABOLIC_RATE: 1.2,     // kcal/min
  INTENSITY_EXPONENT: 2.5,        // Power exponent for exercise multiplier
  RECOVERY_MULTIPLIER: 0.5,       // Hours per TSS point
  MIN_RECOVERY_HOURS: 12,         // Minimum recovery time
  KCAL_TO_KJ_CONVERSION: 4.184,  // Convert kcal to kJ
} as const;

// Time Conversions
export const TIME = {
  SECONDS_PER_MINUTE: 60,
  MINUTES_PER_HOUR: 60,
  SECONDS_PER_HOUR: 3600,
} as const;

// Validation Limits
export const VALIDATION_LIMITS = {
  CRITICAL_VELOCITY: {
    min: 0,
    max: 3.0,  // m/s
  },
  ANAEROBIC_CAPACITY: {
    min: 0,
    max: 100,  // meters
  },
  AEROBIC_POWER: {
    min: 0,
    max: 1000,  // watts
  },
  LACTATE_THRESHOLD: {
    min: 0,
    max: 20,  // mmol/L
  },
  MAX_LACTATE: {
    min: 0,
    max: 30,  // mmol/L
  },
  RECOVERY_RATE: {
    min: 0,
    max: 5,
  },
  VO2_MAX: {
    min: 20,
    max: 100,  // ml/kg/min
  },
  RESTING_HEART_RATE: {
    min: 30,
    max: 120,  // bpm
  },
  MAX_HEART_RATE: {
    min: 100,
    max: 250,  // bpm
  },
  TRAINING_SET: {
    distance: { min: 0, max: 10000 },  // meters
    repetitions: { min: 1, max: 100 },
    restInterval: { min: 0, max: 3600 },  // seconds
  },
} as const;

// Text Input Limits
export const TEXT_LIMITS = {
  NAME: 100,
  NOTES: 1000,
  EMAIL: 255,
} as const;

// Olbrecht Calculation Parameters
export const OLBRECHT = {
  MIN_DATA_POINTS: 2,  // Minimum distance-time pairs for CV calculation
  CONFIDENCE_HIGH: 0.9,
  CONFIDENCE_LOW: 0.7,
  TYPICAL_DISTANCE_MIN: 50,    // meters
  TYPICAL_DISTANCE_MAX: 1500,  // meters
} as const;

// UI Configuration
export const UI = {
  ANIMATION_DURATION: 800,  // ms
  DEBOUNCE_DELAY: 300,      // ms
  MAX_SETS_PREVIEW: 3,      // Number of sets to show in preview
} as const;
