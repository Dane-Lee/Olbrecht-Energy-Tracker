// Validation utilities for input data
import { VALIDATION_LIMITS } from './constants';

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

/**
 * Validate physiological profile values
 */
export const validatePhysiologicalProfile = (profile: {
  criticalVelocity?: number;
  anaerobicCapacity?: number;
  aerobicPower?: number;
  lactateThreshold?: number;
  maxLactate?: number;
  recoveryRate?: number;
  estimatedVO2Max?: number;
  restingHeartRate?: number;
  maxHeartRate?: number;
}): ValidationResult => {
  // Critical Velocity (typical range: 1.0 - 2.5 m/s for swimmers)
  if (profile.criticalVelocity !== undefined) {
    if (profile.criticalVelocity <= VALIDATION_LIMITS.CRITICAL_VELOCITY.min ||
        profile.criticalVelocity > VALIDATION_LIMITS.CRITICAL_VELOCITY.max) {
      return {
        isValid: false,
        error: `Critical velocity must be between ${VALIDATION_LIMITS.CRITICAL_VELOCITY.min} and ${VALIDATION_LIMITS.CRITICAL_VELOCITY.max} m/s`
      };
    }
  }

  // Anaerobic Capacity (typical range: 10-50 meters)
  if (profile.anaerobicCapacity !== undefined) {
    if (profile.anaerobicCapacity < VALIDATION_LIMITS.ANAEROBIC_CAPACITY.min ||
        profile.anaerobicCapacity > VALIDATION_LIMITS.ANAEROBIC_CAPACITY.max) {
      return {
        isValid: false,
        error: `Anaerobic capacity must be between ${VALIDATION_LIMITS.ANAEROBIC_CAPACITY.min} and ${VALIDATION_LIMITS.ANAEROBIC_CAPACITY.max} meters`
      };
    }
  }

  // Aerobic Power (typical range: 100-500 watts)
  if (profile.aerobicPower !== undefined) {
    if (profile.aerobicPower <= 0 || profile.aerobicPower > 1000) {
      return {
        isValid: false,
        error: 'Aerobic power must be between 0 and 1000 watts'
      };
    }
  }

  // Lactate Threshold (typical range: 2-6 mmol/L)
  if (profile.lactateThreshold !== undefined) {
    if (profile.lactateThreshold < 0 || profile.lactateThreshold > 20) {
      return {
        isValid: false,
        error: 'Lactate threshold must be between 0 and 20 mmol/L'
      };
    }
  }

  // Max Lactate (typical range: 8-20 mmol/L)
  if (profile.maxLactate !== undefined) {
    if (profile.maxLactate < 0 || profile.maxLactate > 30) {
      return {
        isValid: false,
        error: 'Max lactate must be between 0 and 30 mmol/L'
      };
    }
  }

  // Recovery Rate (typical range: 0.1-2.0)
  if (profile.recoveryRate !== undefined) {
    if (profile.recoveryRate < 0 || profile.recoveryRate > 5) {
      return {
        isValid: false,
        error: 'Recovery rate must be between 0 and 5'
      };
    }
  }

  // VO2 Max (typical range: 30-80 ml/kg/min)
  if (profile.estimatedVO2Max !== undefined) {
    if (profile.estimatedVO2Max < 20 || profile.estimatedVO2Max > 100) {
      return {
        isValid: false,
        error: 'VO2 Max must be between 20 and 100 ml/kg/min'
      };
    }
  }

  // Resting Heart Rate (typical range: 30-100 bpm)
  if (profile.restingHeartRate !== undefined) {
    if (profile.restingHeartRate < 30 || profile.restingHeartRate > 120) {
      return {
        isValid: false,
        error: 'Resting heart rate must be between 30 and 120 bpm'
      };
    }
  }

  // Max Heart Rate (typical range: 150-220 bpm)
  if (profile.maxHeartRate !== undefined) {
    if (profile.maxHeartRate < 100 || profile.maxHeartRate > 250) {
      return {
        isValid: false,
        error: 'Max heart rate must be between 100 and 250 bpm'
      };
    }
  }

  // Cross-field validation: resting HR should be less than max HR
  if (profile.restingHeartRate !== undefined && profile.maxHeartRate !== undefined) {
    if (profile.restingHeartRate >= profile.maxHeartRate) {
      return {
        isValid: false,
        error: 'Resting heart rate must be less than max heart rate'
      };
    }
  }

  // Cross-field validation: lactate threshold should be less than max lactate
  if (profile.lactateThreshold !== undefined && profile.maxLactate !== undefined) {
    if (profile.lactateThreshold >= profile.maxLactate) {
      return {
        isValid: false,
        error: 'Lactate threshold must be less than max lactate'
      };
    }
  }

  return { isValid: true };
};

/**
 * Validate training session data
 */
export const validateTrainingSet = (set: {
  distance?: number;
  repetitions?: number;
  restInterval?: number;
}): ValidationResult => {
  if (set.distance !== undefined) {
    if (set.distance <= 0 || set.distance > 10000) {
      return {
        isValid: false,
        error: 'Distance must be between 0 and 10000 meters'
      };
    }
  }

  if (set.repetitions !== undefined) {
    if (set.repetitions < 1 || set.repetitions > 100) {
      return {
        isValid: false,
        error: 'Repetitions must be between 1 and 100'
      };
    }
  }

  if (set.restInterval !== undefined) {
    if (set.restInterval < 0 || set.restInterval > 3600) {
      return {
        isValid: false,
        error: 'Rest interval must be between 0 and 3600 seconds'
      };
    }
  }

  return { isValid: true };
};

/**
 * Sanitize text input by trimming and limiting length
 */
export const sanitizeTextInput = (input: string, maxLength: number = 500): string => {
  return input.trim().slice(0, maxLength);
};

/**
 * Validate athlete name
 */
export const validateAthleteName = (name: string): ValidationResult => {
  const sanitized = sanitizeTextInput(name, 100);

  if (sanitized.length === 0) {
    return {
      isValid: false,
      error: 'Name is required'
    };
  }

  if (sanitized.length < 2) {
    return {
      isValid: false,
      error: 'Name must be at least 2 characters'
    };
  }

  return { isValid: true };
};
