import { PhysiologicalProfile, EnergySystemContribution, TrainingLoad } from '../types/training';
import { PerformanceMetrics, IntensityZone } from '../types/performance';

/**
 * Core Olbrecht calculations for energy system modeling
 */

export class OlbrechtCalculator {
  private profile: PhysiologicalProfile;

  constructor(profile: PhysiologicalProfile) {
    this.profile = profile;
  }

  /**
   * Calculate critical velocity from distance-time relationship
   * CV = (D2 - D1) / (T2 - T1)
   */
  static calculateCriticalVelocity(distances: number[], times: number[]): number {
    if (distances.length < 2 || times.length < 2) {
      throw new Error('Need at least 2 data points for CV calculation');
    }

    // Use linear regression on distance vs time
    const n = distances.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;

    for (let i = 0; i < n; i++) {
      sumX += times[i];
      sumY += distances[i];
      sumXY += times[i] * distances[i];
      sumXX += times[i] * times[i];
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
    return slope; // Critical velocity in m/s
  }

  /**
   * Calculate anaerobic capacity (D')
   * D' = intercept of distance-time relationship
   */
  static calculateAnaerobicCapacity(distances: number[], times: number[], cv: number): number {
    const avgDistance = distances.reduce((a, b) => a + b, 0) / distances.length;
    const avgTime = times.reduce((a, b) => a + b, 0) / times.length;
    
    return avgDistance - (cv * avgTime);
  }

  /**
   * Calculate energy system contributions for a given performance
   */
  calculateEnergyContribution(distance: number, time: number): EnergySystemContribution {
    const velocity = distance / time;
    const intensityFactor = velocity / this.profile.criticalVelocity;

    // Olbrecht's energy system model
    let aerobic: number;
    let anaerobicLactic: number;
    let anaerobicAlactic: number;

    if (time <= 10) {
      // Very short duration - primarily phosphocreatine
      anaerobicAlactic = Math.min(95, 85 + (10 - time) * 2);
      anaerobicLactic = Math.max(5, 15 - (10 - time) * 2);
      aerobic = Math.max(0, 100 - anaerobicAlactic - anaerobicLactic);
    } else if (time <= 60) {
      // Short duration - mixed anaerobic
      anaerobicAlactic = Math.max(10, 50 - (time - 10) * 0.8);
      anaerobicLactic = Math.min(70, 30 + (time - 10) * 0.8);
      aerobic = Math.max(20, 100 - anaerobicAlactic - anaerobicLactic);
    } else if (time <= 300) {
      // Medium duration - transitioning to aerobic
      const factor = (time - 60) / 240;
      anaerobicAlactic = Math.max(5, 15 - factor * 10);
      anaerobicLactic = Math.max(15, 60 - factor * 45);
      aerobic = 100 - anaerobicAlactic - anaerobicLactic;
    } else {
      // Long duration - primarily aerobic
      anaerobicAlactic = Math.max(2, 8 - (time - 300) * 0.01);
      anaerobicLactic = Math.max(8, 25 - (time - 300) * 0.02);
      aerobic = 100 - anaerobicAlactic - anaerobicLactic;
    }

    // Adjust based on intensity
    if (intensityFactor > 1.1) {
      anaerobicLactic *= 1.2;
      aerobic *= 0.9;
    } else if (intensityFactor < 0.9) {
      aerobic *= 1.1;
      anaerobicLactic *= 0.8;
    }

    // Normalize to 100%
    const total = aerobic + anaerobicLactic + anaerobicAlactic;
    aerobic = (aerobic / total) * 100;
    anaerobicLactic = (anaerobicLactic / total) * 100;
    anaerobicAlactic = (anaerobicAlactic / total) * 100;

    // Calculate total energy expenditure (simplified model)
    const baseMetabolicRate = 1.2; // kcal/min
    const exerciseMultiplier = Math.pow(intensityFactor, 2.5);
    const totalEnergyExpenditure = (baseMetabolicRate * exerciseMultiplier * (time / 60)) * 4.184; // Convert to kJ

    return {
      aerobic: Math.round(aerobic * 10) / 10,
      anaerobicLactic: Math.round(anaerobicLactic * 10) / 10,
      anaerobicAlactic: Math.round(anaerobicAlactic * 10) / 10,
      totalEnergyExpenditure: Math.round(totalEnergyExpenditure * 10) / 10
    };
  }

  /**
   * Determine intensity zone based on velocity and lactate response
   */
  getIntensityZone(velocity: number): IntensityZone {
    const percentageOfCV = (velocity / this.profile.criticalVelocity) * 100;

    if (percentageOfCV <= 70) {
      return {
        zone: 1,
        name: 'Recovery',
        description: 'Active recovery and easy aerobic work',
        percentageOfCV,
        lactateRange: [1.0, 2.0]
      };
    } else if (percentageOfCV <= 85) {
      return {
        zone: 2,
        name: 'Aerobic Base',
        description: 'Aerobic capacity development',
        percentageOfCV,
        lactateRange: [2.0, 3.0]
      };
    } else if (percentageOfCV <= 100) {
      return {
        zone: 3,
        name: 'Threshold',
        description: 'Lactate threshold training',
        percentageOfCV,
        lactateRange: [3.0, 4.0]
      };
    } else if (percentageOfCV <= 115) {
      return {
        zone: 4,
        name: 'VO2 Max',
        description: 'Maximal aerobic power',
        percentageOfCV,
        lactateRange: [4.0, 8.0]
      };
    } else {
      return {
        zone: 5,
        name: 'Neuromuscular',
        description: 'Speed and power development',
        percentageOfCV,
        lactateRange: [8.0, 15.0]
      };
    }
  }

  /**
   * Calculate training load metrics
   */
  calculateTrainingLoad(sets: any[], sessionDuration: number, historicalSessions?: any[]): TrainingLoad {
    let totalVolume = 0;
    let weightedIntensity = 0;
    let totalIntensityTime = 0;

    sets.forEach(set => {
      const setVolume = set.distance * set.repetitions;
      totalVolume += setVolume;

      set.times.forEach((time: number) => {
        const velocity = set.distance / time;
        const intensity = velocity / this.profile.criticalVelocity;
        weightedIntensity += intensity * time;
        totalIntensityTime += time;
      });
    });

    const averageIntensity = totalIntensityTime > 0 ? weightedIntensity / totalIntensityTime : 0;

    // Training Stress Score calculation (adapted for swimming)
    const normalizedPower = Math.pow(averageIntensity, 4);
    const intensityFactor = normalizedPower / Math.pow(1.0, 4); // Normalized to threshold
    const trainingStressScore = (sessionDuration / 3600) * intensityFactor * 100;

    // Calculate monotony and strain if historical data is available
    let monotony = 1.0;
    let strain = trainingStressScore;
    
    if (historicalSessions && historicalSessions.length > 0) {
      const recentTSS = historicalSessions.slice(-7).map(s => s.trainingLoad?.trainingStressScore || 0);
      recentTSS.push(trainingStressScore);
      
      const avgTSS = recentTSS.reduce((sum, tss) => sum + tss, 0) / recentTSS.length;
      const variance = recentTSS.reduce((sum, tss) => sum + Math.pow(tss - avgTSS, 2), 0) / recentTSS.length;
      const stdDev = Math.sqrt(variance);
      
      monotony = stdDev > 0 ? avgTSS / stdDev : 1.0;
      strain = avgTSS * monotony;
    }
    // Recovery time estimation (hours)
    const recoveryTime = Math.max(12, trainingStressScore * 0.5);

    return {
      volume: totalVolume,
      intensity: Math.round(averageIntensity * 100) / 100,
      trainingStressScore: Math.round(trainingStressScore * 10) / 10,
      monotony: Math.round(monotony * 100) / 100,
      strain: Math.round(strain * 10) / 10,
      recoveryTime: Math.round(recoveryTime)
    };
  }

  /**
   * Predict performance for a given distance
   */
  predictPerformance(distance: number): { time: number; confidence: number } {
    const { criticalVelocity, anaerobicCapacity } = this.profile;
    
    // Olbrecht's distance-time model: T = D/CV + D'/CV²
    const time = distance / criticalVelocity + anaerobicCapacity / Math.pow(criticalVelocity, 2);
    
    // Confidence decreases with distance from typical training distances
    let confidence = 0.9;
    if (distance > 1500 || distance < 50) {
      confidence *= 0.7;
    }

    return {
      time: Math.round(time * 100) / 100,
      confidence: Math.round(confidence * 100) / 100
    };
  }
}

/**
 * Utility functions for common calculations
 */
export const formatTime = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toFixed(2).padStart(5, '0')}`;
};

export const formatPace = (seconds: number, distance: number): string => {
  const pace100m = (seconds / distance) * 100;
  return formatTime(pace100m);
};

export const calculateVelocity = (distance: number, time: number): number => {
  return distance / time;
};