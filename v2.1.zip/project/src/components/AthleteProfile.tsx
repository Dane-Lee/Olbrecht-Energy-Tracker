import React, { useState } from 'react';
import { User, Edit3, Save, X, Calendar, Mail, Ruler, Target, Trophy, Camera, Calculator } from 'lucide-react';
import { Athlete, PhysiologicalProfile } from '../types/athlete';
import { OlbrechtCalculator } from '../utils/olbrechtCalculations';
import { validatePhysiologicalProfile } from '../utils/validation';

interface AthleteProfileProps {
  athlete: Athlete;
  onUpdateProfile: (profile: PhysiologicalProfile) => void;
  onUpdateAthlete: (athleteData: Partial<Athlete>) => void;
}

export const AthleteProfile: React.FC<AthleteProfileProps> = ({
  athlete,
  onUpdateProfile,
  onUpdateAthlete
}) => {
  const [isEditingBasic, setIsEditingBasic] = useState(false);
  const [isEditingPhysio, setIsEditingPhysio] = useState(false);
  const [isEditingBests, setIsEditingBests] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calculatorError, setCalculatorError] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [testDistances, setTestDistances] = useState<string>('400,100');
  const [testTimes, setTestTimes] = useState<string>('300,65');
  const [basicInfo, setBasicInfo] = useState({
    name: athlete.name,
    email: athlete.email,
    dateOfBirth: athlete.dateOfBirth,
    gender: athlete.gender,
    specialtyDistance: athlete.specialtyDistance,
    specialtyStroke: athlete.specialtyStroke || 'freestyle',
    specialtyRaceType: athlete.specialtyRaceType || 'sprint',
    profilePicture: athlete.profilePicture || ''
  });
  const [physioProfile, setPhysioProfile] = useState(athlete.physiologicalProfile);
  const [personalBests, setPersonalBests] = useState(athlete.personalBests || {});

  const handleSaveBasic = () => {
    onUpdateAthlete(basicInfo);
    setIsEditingBasic(false);
  };

  const handleCancelBasic = () => {
    setBasicInfo({
      name: athlete.name,
      email: athlete.email,
      dateOfBirth: athlete.dateOfBirth,
      gender: athlete.gender,
      specialtyDistance: athlete.specialtyDistance,
      specialtyStroke: athlete.specialtyStroke || 'freestyle',
      specialtyRaceType: athlete.specialtyRaceType || 'sprint',
      profilePicture: athlete.profilePicture || ''
    });
    setIsEditingBasic(false);
  };

  const handleSavePhysio = () => {
    // Validate physiological profile before saving
    const validation = validatePhysiologicalProfile(physioProfile);
    if (!validation.isValid) {
      setValidationError(validation.error || 'Invalid physiological profile values');
      return;
    }

    setValidationError(null);
    onUpdateProfile(physioProfile);
    setIsEditingPhysio(false);
  };

  const handleCancelPhysio = () => {
    setPhysioProfile(athlete.physiologicalProfile);
    setValidationError(null);
    setIsEditingPhysio(false);
  };

  const handleSaveBests = () => {
    onUpdateAthlete({ personalBests });
    setIsEditingBests(false);
  };

  const handleCancelBests = () => {
    setPersonalBests(athlete.personalBests || {});
    setIsEditingBests(false);
  };

  const handleCalculateCV = () => {
    setCalculatorError(null);
    try {
      const distances = testDistances.split(',').map(d => parseFloat(d.trim()));
      const times = testTimes.split(',').map(t => parseFloat(t.trim()));

      // Validate inputs
      if (distances.some(isNaN) || times.some(isNaN)) {
        setCalculatorError('Please enter valid numbers for distances and times');
        return;
      }

      if (distances.length !== times.length || distances.length < 2) {
        setCalculatorError('Please provide at least 2 distance-time pairs, separated by commas');
        return;
      }

      if (distances.some(d => d <= 0) || times.some(t => t <= 0)) {
        setCalculatorError('Distances and times must be positive numbers');
        return;
      }

      const cv = OlbrechtCalculator.calculateCriticalVelocity(distances, times);
      const anaerobicCapacity = OlbrechtCalculator.calculateAnaerobicCapacity(distances, times, cv);

      setPhysioProfile({
        ...physioProfile,
        criticalVelocity: cv,
        anaerobicCapacity
      });

      setShowCalculator(false);
      setCalculatorError(null);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error calculating critical velocity';
      setCalculatorError(errorMessage);
    }
  };

  const updatePersonalBest = (distance: number, time: number) => {
    setPersonalBests({
      ...personalBests,
      [distance]: time
    });
  };

  const removePersonalBest = (distance: number) => {
    const newBests = { ...personalBests };
    delete newBests[distance];
    setPersonalBests(newBests);
  };
  return (
    <div className="space-y-4">
      {/* Training Summary */}
      <div className="bg-gray-800 rounded-xl shadow-lg p-4 border border-gray-700">
        <h3 className="text-lg font-semibold text-gray-100 mb-2">Training Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-400">{athlete.sessions.length}</p>
            <p className="text-sm text-gray-400">Total Sessions</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400">
              {(athlete.sessions.reduce((sum, s) => sum + s.totalDistance, 0) / 1000).toFixed(1)}km
            </p>
            <p className="text-sm text-gray-400">Total Distance</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-purple-400">
              {Math.floor(athlete.sessions.reduce((sum, s) => sum + s.totalTime, 0) / 60)}h
            </p>
            <p className="text-sm text-gray-400">Total Time</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-orange-400">
              {athlete.sessions.length > 0 
                ? (athlete.sessions.reduce((sum, s) => sum + s.averageIntensity, 0) / athlete.sessions.length * 100).toFixed(0)
                : 0}%
            </p>
            <p className="text-sm text-gray-400">Avg Intensity</p>
          </div>
        </div>
      </div>

      {/* Basic Information */}
      <div className="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-100">Basic Information</h3>
          </div>
          {!isEditingBasic ? (
            <button
              onClick={() => setIsEditingBasic(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit</span>
            </button>
          ) : (
            <div className="flex space-x-2">
              <button
                onClick={handleSaveBasic}
                className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Save</span>
              </button>
              <button
                onClick={handleCancelBasic}
                className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <User className="w-4 h-4 inline mr-2" />
              Name
            </label>
            {isEditingBasic ? (
              <input
                type="text"
                value={basicInfo.name}
                onChange={(e) => setBasicInfo({ ...basicInfo, name: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.name}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Mail className="w-4 h-4 inline mr-2" />
              Email
            </label>
            {isEditingBasic ? (
              <input
                type="email"
                value={basicInfo.email}
                onChange={(e) => setBasicInfo({ ...basicInfo, email: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.email || 'Not set'}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Calendar className="w-4 h-4 inline mr-2" />
              Date of Birth
            </label>
            {isEditingBasic ? (
              <input
                type="date"
                value={basicInfo.dateOfBirth}
                onChange={(e) => setBasicInfo({ ...basicInfo, dateOfBirth: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{new Date(athlete.dateOfBirth).toLocaleDateString()}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Gender
            </label>
            {isEditingBasic ? (
              <select
                value={basicInfo.gender}
                onChange={(e) => setBasicInfo({ ...basicInfo, gender: e.target.value as 'male' | 'female' })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            ) : (
              <p className="text-gray-100 py-2 capitalize">{athlete.gender}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Camera className="w-4 h-4 inline mr-2" />
              Profile Picture URL
            </label>
            {isEditingBasic ? (
              <input
                type="url"
                value={basicInfo.profilePicture}
                onChange={(e) => setBasicInfo({ ...basicInfo, profilePicture: e.target.value })}
                placeholder="https://example.com/profile.jpg"
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <div className="flex items-center space-x-3 py-2">
                {athlete.profilePicture ? (
                  <img 
                    src={athlete.profilePicture} 
                    alt={athlete.name}
                    className="w-12 h-12 rounded-full object-cover"
                    onError={(e) => { e.target.style.display = 'none'; }}
                  />
                ) : (
                  <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-gray-400" />
                  </div>
                )}
                <p className="text-gray-100">{athlete.profilePicture || 'Not set'}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Personal Bests */}
      <div className="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl flex items-center justify-center">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-100">Personal Bests</h3>
          </div>
          {!isEditingBests ? (
            <button
              onClick={() => setIsEditingBests(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit</span>
            </button>
          ) : (
            <div className="flex space-x-2">
              <button
                onClick={handleSaveBests}
                className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Save</span>
              </button>
              <button
                onClick={handleCancelBests}
                className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </div>
          )}
        </div>

        <div className="space-y-4">
          {Object.entries(personalBests).map(([distance, time]) => (
            <div key={distance} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
              <span className="text-gray-200">{distance}m</span>
              {isEditingBests ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    step="0.01"
                    value={time}
                    onChange={(e) => updatePersonalBest(parseInt(distance), parseFloat(e.target.value))}
                    className="w-24 px-2 py-1 text-sm bg-gray-600 text-gray-100 border border-gray-500 rounded"
                  />
                  <span className="text-sm text-gray-400">seconds</span>
                  <button
                    onClick={() => removePersonalBest(parseInt(distance))}
                    className="text-red-400 hover:text-red-300"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <span className="font-semibold text-gray-100">
                  {Math.floor(time / 60)}:{(time % 60).toFixed(2).padStart(5, '0')}
                </span>
              )}
            </div>
          ))}
          
          {isEditingBests && (
            <div className="flex items-center space-x-2 p-3 border-2 border-dashed border-gray-600 rounded-lg">
              <input
                type="number"
                placeholder="Distance (m)"
                className="w-24 px-2 py-1 text-sm bg-gray-600 text-gray-100 border border-gray-500 rounded"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const distance = parseFloat(e.target.value);
                    const timeInput = e.target.nextElementSibling;
                    const time = parseFloat(timeInput.value);
                    if (distance && time) {
                      updatePersonalBest(distance, time);
                      e.target.value = '';
                      timeInput.value = '';
                    }
                  }
                }}
              />
              <input
                type="number"
                step="0.01"
                placeholder="Time (s)"
                className="w-24 px-2 py-1 text-sm bg-gray-600 text-gray-100 border border-gray-500 rounded"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const timeInput = e.target;
                    const distanceInput = e.target.previousElementSibling;
                    const distance = parseFloat(distanceInput.value);
                    const time = parseFloat(timeInput.value);
                    if (distance && time) {
                      updatePersonalBest(distance, time);
                      distanceInput.value = '';
                      timeInput.value = '';
                    }
                  }
                }}
              />
              <span className="text-sm text-gray-400">Press Enter to add</span>
            </div>
          )}
          
          {Object.keys(personalBests).length === 0 && !isEditingBests && (
            <div className="text-center py-8">
              <Trophy className="w-8 h-8 text-gray-500 mx-auto mb-2" />
              <p className="text-sm text-gray-400">No personal bests recorded yet</p>
            </div>
          )}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Ruler className="w-4 h-4 inline mr-2" />
              Specialty Distance (m)
            </label>
            {isEditingBasic ? (
              <input
                type="number"
                value={basicInfo.specialtyDistance}
                onChange={(e) => setBasicInfo({ ...basicInfo, specialtyDistance: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.specialtyDistance}m</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Specialty Stroke
            </label>
            {isEditingBasic ? (
              <select
                value={basicInfo.specialtyStroke}
                onChange={(e) => setBasicInfo({ ...basicInfo, specialtyStroke: e.target.value as any })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="freestyle">Freestyle</option>
                <option value="backstroke">Backstroke</option>
                <option value="breaststroke">Breaststroke</option>
                <option value="butterfly">Butterfly</option>
                <option value="individual-medley">Individual Medley</option>
              </select>
            ) : (
              <p className="text-gray-100 py-2 capitalize">{(athlete.specialtyStroke || 'freestyle').replace('-', ' ')}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Race Type
            </label>
            {isEditingBasic ? (
              <select
                value={basicInfo.specialtyRaceType}
                onChange={(e) => setBasicInfo({ ...basicInfo, specialtyRaceType: e.target.value as any })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="sprint">Sprint (50m-100m)</option>
                <option value="middle-distance">Middle Distance (200m-400m)</option>
                <option value="distance">Distance (800m+)</option>
                <option value="open-water">Open Water</option>
              </select>
            ) : (
              <p className="text-gray-100 py-2 capitalize">{(athlete.specialtyRaceType || 'sprint').replace('-', ' ')}</p>
            )}
          </div>
        </div>
      </div>

      {/* Physiological Profile */}
      <div className="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-100">Physiological Profile</h3>
          </div>
          <div className="flex space-x-2">
            {!showCalculator && (
              <button
                onClick={() => setShowCalculator(true)}
                className="flex items-center space-x-2 px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Calculator className="w-4 h-4" />
                <span>Calculate CV</span>
              </button>
            )}
            {!isEditingPhysio ? (
            <button
              onClick={() => setIsEditingPhysio(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit</span>
            </button>
            ) : (
            <div className="flex space-x-2">
              <button
                onClick={handleSavePhysio}
                className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Save</span>
              </button>
              <button
                onClick={handleCancelPhysio}
                className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </div>
            )}
          </div>
        </div>

        {/* Critical Velocity Calculator */}
        {showCalculator && (
          <div className="mb-6 p-4 bg-purple-900/20 border border-purple-700/50 rounded-lg">
            <h4 className="text-lg font-medium text-purple-200 mb-3">Critical Velocity Calculator</h4>
            <p className="text-sm text-purple-100 mb-4">
              Enter at least 2 distance-time pairs separated by commas. Example: 400,100 for distances and 300,65 for times.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-purple-200 mb-1">
                  Distances (meters)
                </label>
                <input
                  type="text"
                  value={testDistances}
                  onChange={(e) => setTestDistances(e.target.value)}
                  placeholder="400,100,50"
                  className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-purple-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-purple-200 mb-1">
                  Times (seconds)
                </label>
                <input
                  type="text"
                  value={testTimes}
                  onChange={(e) => setTestTimes(e.target.value)}
                  placeholder="300,65,30"
                  className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-purple-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
            </div>
            {calculatorError && (
              <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-lg">
                <p className="text-sm text-red-200">{calculatorError}</p>
              </div>
            )}
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => {
                  setShowCalculator(false);
                  setCalculatorError(null);
                }}
                className="px-4 py-2 text-purple-300 hover:text-purple-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleCalculateCV}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Calculate
              </button>
            </div>
          </div>
        )}

        {validationError && isEditingPhysio && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-lg">
            <p className="text-sm text-red-200">{validationError}</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Critical Velocity (m/s)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                step="0.01"
                value={physioProfile.criticalVelocity}
                onChange={(e) => setPhysioProfile({ ...physioProfile, criticalVelocity: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.criticalVelocity.toFixed(2)} m/s</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Anaerobic Capacity (m)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                step="0.1"
                value={physioProfile.anaerobicCapacity}
                onChange={(e) => setPhysioProfile({ ...physioProfile, anaerobicCapacity: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.anaerobicCapacity.toFixed(1)} m</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Aerobic Power (W)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                value={physioProfile.aerobicPower}
                onChange={(e) => setPhysioProfile({ ...physioProfile, aerobicPower: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.aerobicPower} W</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Max Lactate (mmol/L)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                step="0.1"
                value={physioProfile.maxLactate}
                onChange={(e) => setPhysioProfile({ ...physioProfile, maxLactate: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.maxLactate.toFixed(1)} mmol/L</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Recovery Rate
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                step="0.01"
                value={physioProfile.recoveryRate}
                onChange={(e) => setPhysioProfile({ ...physioProfile, recoveryRate: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.recoveryRate.toFixed(2)}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              VO2 Max (ml/kg/min)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                value={physioProfile.estimatedVO2Max}
                onChange={(e) => setPhysioProfile({ ...physioProfile, estimatedVO2Max: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.estimatedVO2Max} ml/kg/min</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Resting HR (bpm)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                value={physioProfile.restingHeartRate}
                onChange={(e) => setPhysioProfile({ ...physioProfile, restingHeartRate: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.restingHeartRate} bpm</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Max HR (bpm)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                value={physioProfile.maxHeartRate}
                onChange={(e) => setPhysioProfile({ ...physioProfile, maxHeartRate: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.maxHeartRate} bpm</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Lactate Threshold (mmol/L)
            </label>
            {isEditingPhysio ? (
              <input
                type="number"
                step="0.1"
                value={physioProfile.lactateThreshold}
                onChange={(e) => setPhysioProfile({ ...physioProfile, lactateThreshold: parseFloat(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-100 py-2">{athlete.physiologicalProfile.lactateThreshold.toFixed(1)} mmol/L</p>
            )}
          </div>
        </div>

        {/* Performance Predictions */}
        <div className="mt-6 pt-6 border-t border-gray-700">
          <h4 className="text-lg font-medium text-gray-200 mb-4">Performance Predictions</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[50, 100, 200, 400, 800, 1500].map(distance => {
              const calculator = new OlbrechtCalculator(athlete.physiologicalProfile);
              const prediction = calculator.predictPerformance(distance);
              return (
                <div key={distance} className="text-center p-3 bg-gray-700 rounded-lg">
                  <p className="text-sm text-gray-400">{distance}m</p>
                  <p className="font-semibold text-gray-200">
                    {Math.floor(prediction.time / 60)}:{(prediction.time % 60).toFixed(2).padStart(5, '0')}
                  </p>
                  <p className="text-xs text-gray-500">{(prediction.confidence * 100).toFixed(0)}% confident</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};