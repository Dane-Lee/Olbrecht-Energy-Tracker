import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { EnergySystemContribution } from '../types/training';

interface EnergySystemChartProps {
  energyContribution: EnergySystemContribution;
  size?: 'small' | 'medium' | 'large';
}

export const EnergySystemChart: React.FC<EnergySystemChartProps> = React.memo(({
  energyContribution,
  size = 'medium'
}) => {
  const data = useMemo(() => [
    {
      name: 'Aerobic',
      value: energyContribution.aerobic,
      color: '#3B82F6',
      description: 'Oxygen-dependent energy production'
    },
    {
      name: 'Anaerobic Lactic',
      value: energyContribution.anaerobicLactic,
      color: '#EF4444',
      description: 'Glycolytic system with lactate production'
    },
    {
      name: 'Anaerobic Alactic',
      value: energyContribution.anaerobicAlactic,
      color: '#10B981',
      description: 'Phosphocreatine system'
    }
  ], [energyContribution]);

  const sizeConfig = {
    small: { width: 200, height: 200, innerRadius: 40, outerRadius: 80 },
    medium: { width: 300, height: 300, innerRadius: 60, outerRadius: 120 },
    large: { width: 400, height: 400, innerRadius: 80, outerRadius: 160 }
  };

  const config = sizeConfig[size];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-gray-800 text-gray-100 p-3 border border-gray-600 rounded-lg shadow-lg">
          <p className="font-semibold" style={{ color: data.color }}>
            {data.name}
          </p>
          <p className="text-sm text-gray-400">{data.description}</p>
          <p className="font-bold">{data.value.toFixed(1)}%</p>
        </div>
      );
    }
    return null;
  };

  const CustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    if (percent < 0.05) return null; // Don't show labels for very small slices
    
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontSize={size === 'small' ? 10 : 12}
        fontWeight="bold"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
      <h3 className="text-lg font-semibold mb-4 text-center text-gray-100">Energy System Contribution</h3>
      
      <ResponsiveContainer width="100%" height={config.height}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={CustomLabel}
            outerRadius={config.outerRadius}
            innerRadius={config.innerRadius}
            fill="#8884d8"
            dataKey="value"
            animationBegin={0}
            animationDuration={800}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            verticalAlign="bottom" 
            height={36}
            formatter={(value, entry: any) => (
              <span style={{ color: entry.color, fontWeight: 500 }}>
                {value}
              </span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-400">
          Total Energy: <span className="font-semibold text-gray-200">{energyContribution.totalEnergyExpenditure.toFixed(1)} kJ</span>
        </p>
      </div>
    </div>
  );
});