import React, { useMemo } from 'react';
import { Calendar, Clock, Target, Activity, TrendingUp } from 'lucide-react';
import { TrainingSession } from '../types/training';
import { EnergySystemChart } from './EnergySystemChart';
import { formatTime } from '../utils/olbrechtCalculations';

interface SessionListProps {
  sessions: TrainingSession[];
  onSelectSession: (session: TrainingSession) => void;
}

export const SessionList: React.FC<SessionListProps> = React.memo(({ sessions, onSelectSession }) => {
  const sortedSessions = useMemo(() =>
    [...sessions].sort((a, b) =>
      new Date(b.date).getTime() - new Date(a.date).getTime()
    ),
    [sessions]
  );

  const getSessionTypeColor = (type: string) => {
    switch (type) {
      case 'competition': return 'bg-red-900/30 text-red-300 border-red-700/50';
      case 'test': return 'bg-purple-900/30 text-purple-300 border-purple-700/50';
      default: return 'bg-blue-900/30 text-blue-300 border-blue-700/50';
    }
  };

  const getIntensityColor = (intensity: number) => {
    if (intensity >= 1.1) return 'text-red-400';
    if (intensity >= 1.0) return 'text-orange-400';
    if (intensity >= 0.9) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <div className="space-y-4">
      {sortedSessions.length === 0 ? (
        <div className="text-center py-12">
          <Activity className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-200 mb-2">No training sessions yet</h3>
          <p className="text-gray-400">Start by adding your first training session to track progress.</p>
        </div>
      ) : (
        sortedSessions.map((session) => (
          <div
            key={session.id}
            onClick={() => onSelectSession(session)}
            className="bg-gray-800 rounded-lg shadow-lg border border-gray-700 p-4 hover:bg-gray-750 transition-colors cursor-pointer"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-300">
                    {new Date(session.date).toLocaleDateString()}
                  </span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSessionTypeColor(session.sessionType)}`}>
                  {session.sessionType.charAt(0).toUpperCase() + session.sessionType.slice(1)}
                </span>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-400">Training Load</p>
                <p className="font-semibold text-lg text-gray-200">{session.trainingLoad.trainingStressScore.toFixed(0)} TSS</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-2 mb-2">
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4 text-blue-400" />
                <div>
                  <p className="text-xs text-gray-400">Distance</p>
                  <p className="font-semibold text-gray-200">{session.totalDistance.toLocaleString()}m</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-green-400" />
                <div>
                  <p className="text-xs text-gray-400">Time</p>
                  <p className="font-semibold text-gray-200">{formatTime(session.totalTime)}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <div>
                  <p className="text-xs text-gray-400">Intensity</p>
                  <p className={`font-semibold ${getIntensityColor(session.averageIntensity)}`}>
                    {(session.averageIntensity * 100).toFixed(0)}% CV
                  </p>
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-400">Recovery</p>
                <p className="font-semibold text-gray-200">{session.trainingLoad.recoveryTime}h</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <div>
                <h4 className="text-sm font-medium text-gray-300 mb-2">Sets Overview</h4>
                <div className="space-y-1">
                  {session.sets.slice(0, 3).map((set, index) => (
                    <div key={set.id} className="text-sm text-gray-400">
                      {set.repetitions}x{set.distance}m @ {formatTime(set.times[0])}
                      {set.times.length > 1 && ` (avg)`}
                    </div>
                  ))}
                  {session.sets.length > 3 && (
                    <div className="text-sm text-gray-500">
                      +{session.sets.length - 3} more sets
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-center">
                <EnergySystemChart 
                  energyContribution={session.energySystemContribution} 
                  size="small"
                />
              </div>
            </div>

            {session.notes && (
              <div className="mt-4 pt-4 border-t border-gray-700">
                <p className="text-sm text-gray-300">{session.notes}</p>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
});