import React, { useState } from 'react';
import { Plus, Trash2, Clock, Target, Save, ArrowLeft } from 'lucide-react';
import { TrainingSession, TrainingSet } from '../types/training';
import { OlbrechtCalculator } from '../utils/olbrechtCalculations';
import { PhysiologicalProfile } from '../types/athlete';

interface TrainingSessionFormProps {
  profile: PhysiologicalProfile;
  onSave: (session: Omit<TrainingSession, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export const TrainingSessionForm: React.FC<TrainingSessionFormProps> = ({
  profile,
  onSave,
  onCancel
}) => {
  const [sessionType, setSessionType] = useState<'training' | 'competition' | 'test'>('training');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [sets, setSets] = useState<Omit<TrainingSet, 'id'>[]>([
    {
      distance: 100,
      repetitions: 1,
      times: [60],
      restInterval: 0,
      strokeRate: [],
      heartRate: [],
      perceivedExertion: [],
      lactateValues: []
    }
  ]);
  const [notes, setNotes] = useState('');

  const calculator = new OlbrechtCalculator(profile);

  const addSet = () => {
    setSets([...sets, {
      distance: 100,
      repetitions: 1,
      times: [60],
      restInterval: 0,
      strokeRate: [],
      heartRate: [],
      perceivedExertion: [],
      lactateValues: []
    }]);
  };

  const removeSet = (index: number) => {
    setSets(sets.filter((_, i) => i !== index));
  };

  const updateSet = (index: number, field: string, value: any) => {
    const updatedSets = [...sets];
    updatedSets[index] = { ...updatedSets[index], [field]: value };
    setSets(updatedSets);
  };

  const updateSetTime = (setIndex: number, repIndex: number, time: number) => {
    const updatedSets = [...sets];
    const newTimes = [...updatedSets[setIndex].times];
    newTimes[repIndex] = time;
    updatedSets[setIndex] = { ...updatedSets[setIndex], times: newTimes };
    setSets(updatedSets);
  };

  const adjustRepetitions = (setIndex: number, newReps: number) => {
    const updatedSets = [...sets];
    const currentTimes = updatedSets[setIndex].times;
    
    if (newReps > currentTimes.length) {
      // Add new times with the last time as default
      const lastTime = currentTimes[currentTimes.length - 1] || 60;
      const newTimes = [...currentTimes, ...Array(newReps - currentTimes.length).fill(lastTime)];
      updatedSets[setIndex] = { ...updatedSets[setIndex], repetitions: newReps, times: newTimes };
    } else {
      // Remove excess times
      updatedSets[setIndex] = { 
        ...updatedSets[setIndex], 
        repetitions: newReps, 
        times: currentTimes.slice(0, newReps) 
      };
    }
    
    setSets(updatedSets);
  };

  const calculateSessionMetrics = () => {
    let totalDistance = 0;
    let totalTime = 0;
    let weightedIntensity = 0;
    let totalIntensityTime = 0;

    sets.forEach(set => {
      const setVolume = set.distance * set.repetitions;
      totalDistance += setVolume;
      
      set.times.forEach(time => {
        totalTime += time;
        const velocity = set.distance / time;
        const intensity = velocity / profile.criticalVelocity;
        weightedIntensity += intensity * time;
        totalIntensityTime += time;
      });
    });

    const averageIntensity = totalIntensityTime > 0 ? weightedIntensity / totalIntensityTime : 0;
    
    // Calculate energy contribution for the session
    const sessionEnergyContribution = calculator.calculateEnergyContribution(totalDistance, totalTime);
    
    // Calculate training load
    const trainingLoad = calculator.calculateTrainingLoad(sets, totalTime, []);

    return {
      totalDistance,
      totalTime,
      averageIntensity,
      sessionEnergyContribution,
      trainingLoad
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const metrics = calculateSessionMetrics();
    
    const session: Omit<TrainingSession, 'id' | 'createdAt'> = {
      date,
      sessionType,
      sets: sets.map((set, index) => ({
        ...set,
        id: `set-${index}`
      })),
      totalDistance: metrics.totalDistance,
      totalTime: metrics.totalTime,
      averageIntensity: metrics.averageIntensity,
      energySystemContribution: metrics.sessionEnergyContribution,
      trainingLoad: metrics.trainingLoad,
      notes: notes.trim() || undefined
    };

    onSave(session);
  };

  const metrics = calculateSessionMetrics();

  return (
    <div className="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-100">New Training Session</h2>
        <button
          onClick={onCancel}
          className="flex items-center space-x-2 px-3 py-2 text-gray-400 hover:text-gray-200 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Session Type
            </label>
            <select
              value={sessionType}
              onChange={(e) => setSessionType(e.target.value as 'training' | 'competition' | 'test')}
              className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="training">Training</option>
              <option value="competition">Competition</option>
              <option value="test">Test</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Date
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-100">Training Sets</h3>
            <button
              type="button"
              onClick={addSet}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Set</span>
            </button>
          </div>

          <div className="space-y-4">
            {sets.map((set, setIndex) => (
              <div key={setIndex} className="border border-gray-600 bg-gray-700/50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-200">Set {setIndex + 1}</h4>
                  {sets.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSet(setIndex)}
                      className="text-red-400 hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Distance (m)
                    </label>
                    <input
                      type="number"
                      value={set.distance}
                      onChange={(e) => updateSet(setIndex, 'distance', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Repetitions
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={set.repetitions}
                      onChange={(e) => adjustRepetitions(setIndex, parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Rest Interval (s)
                    </label>
                    <input
                      type="number"
                      value={set.restInterval}
                      onChange={(e) => updateSet(setIndex, 'restInterval', parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Times (seconds)
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
                    {set.times.map((time, repIndex) => (
                      <div key={repIndex} className="relative">
                        <input
                          type="number"
                          step="0.01"
                          value={time}
                          onChange={(e) => updateSetTime(setIndex, repIndex, parseFloat(e.target.value))}
                          className="w-full px-2 py-1 text-sm bg-gray-700 text-gray-100 border border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                          placeholder={`Rep ${repIndex + 1}`}
                        />
                        <div className="absolute -top-1 -right-1 bg-blue-600 text-blue-100 text-xs px-1 rounded">
                          {repIndex + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Training Set Data */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Stroke Rate (per rep, optional)
                    </label>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                      {Array.from({ length: set.repetitions }, (_, repIndex) => (
                        <input
                          key={repIndex}
                          type="number"
                          step="1"
                          value={set.strokeRate?.[repIndex] || ''}
                          onChange={(e) => {
                            const newStrokeRate = [...(set.strokeRate || Array(set.repetitions).fill(null))];
                            newStrokeRate[repIndex] = e.target.value ? parseFloat(e.target.value) : null;
                            updateSet(setIndex, 'strokeRate', newStrokeRate);
                          }}
                          placeholder={`${repIndex + 1}`}
                          className="px-2 py-1 text-xs bg-gray-700 text-gray-100 border border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Heart Rate (per rep, optional)
                    </label>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                      {Array.from({ length: set.repetitions }, (_, repIndex) => (
                        <input
                          key={repIndex}
                          type="number"
                          step="1"
                          value={set.heartRate?.[repIndex] || ''}
                          onChange={(e) => {
                            const newHeartRate = [...(set.heartRate || Array(set.repetitions).fill(null))];
                            newHeartRate[repIndex] = e.target.value ? parseInt(e.target.value) : null;
                            updateSet(setIndex, 'heartRate', newHeartRate);
                          }}
                          placeholder={`${repIndex + 1}`}
                          className="px-2 py-1 text-xs bg-gray-700 text-gray-100 border border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Perceived Exertion (1-10, per rep, optional)
                    </label>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                      {Array.from({ length: set.repetitions }, (_, repIndex) => (
                        <input
                          key={repIndex}
                          type="number"
                          min="1"
                          max="10"
                          step="1"
                          value={set.perceivedExertion?.[repIndex] || ''}
                          onChange={(e) => {
                            const newPE = [...(set.perceivedExertion || Array(set.repetitions).fill(null))];
                            newPE[repIndex] = e.target.value ? parseInt(e.target.value) : null;
                            updateSet(setIndex, 'perceivedExertion', newPE);
                          }}
                          placeholder={`${repIndex + 1}`}
                          className="px-2 py-1 text-xs bg-gray-700 text-gray-100 border border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Lactate Values (mmol/L, per rep, optional)
                    </label>
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                      {Array.from({ length: set.repetitions }, (_, repIndex) => (
                        <input
                          key={repIndex}
                          type="number"
                          step="0.1"
                          value={set.lactateValues?.[repIndex] || ''}
                          onChange={(e) => {
                            const newLactate = [...(set.lactateValues || Array(set.repetitions).fill(null))];
                            newLactate[repIndex] = e.target.value ? parseFloat(e.target.value) : null;
                            updateSet(setIndex, 'lactateValues', newLactate);
                          }}
                          placeholder={`${repIndex + 1}`}
                          className="px-2 py-1 text-xs bg-gray-700 text-gray-100 border border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Notes (optional)
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 bg-gray-700 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Session notes, observations, or comments..."
          />
        </div>

        {/* Session Preview */}
        <div className="bg-gray-700 rounded-lg p-4 border border-gray-600">
          <h3 className="font-semibold mb-3 text-gray-100">Session Preview</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              <Target className="w-4 h-4 text-blue-400" />
              <div>
                <p className="text-xs text-gray-400">Total Distance</p>
                <p className="font-semibold text-gray-200">{metrics.totalDistance}m</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-green-400" />
              <div>
                <p className="text-xs text-gray-400">Total Time</p>
                <p className="font-semibold text-gray-200">
                  {Math.floor(metrics.totalTime / 60)}:{(metrics.totalTime % 60).toFixed(0).padStart(2, '0')}
                </p>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-400">Avg Intensity</p>
              <p className="font-semibold text-gray-200">{(metrics.averageIntensity * 100).toFixed(0)}% CV</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">Training Load</p>
              <p className="font-semibold text-gray-200">{metrics.trainingLoad.trainingStressScore.toFixed(0)} TSS</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center space-x-2 px-6 py-2 text-gray-300 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Cancel</span>
          </button>
          <button
            type="submit"
            className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Session</span>
          </button>
        </div>
      </form>
    </div>
  );
};