import React, { useState } from 'react';
import { User, Plus, Users, Activity, ArrowLeft, UserCheck } from 'lucide-react';
import { Athlete } from '../types/athlete';
import { Team } from '../types/team';

interface AthleteSelectorProps {
  athletes: Athlete[];
  selectedAthleteId: string | null;
  onSelectAthlete: (athleteId: string) => void;
  onAddAthlete: (name: string, teamId?: string) => void;
  teams: Team[];
  onAddTeam: (name: string) => void;
  activeSidebarTab: 'athletes' | 'teams';
  setActiveSidebarTab: (tab: 'athletes' | 'teams') => void;
  selectedTeamId: string | null;
  setSelectedTeamId: (teamId: string | null) => void;
}

export const AthleteSelector: React.FC<AthleteSelectorProps> = ({
  athletes,
  selectedAthleteId,
  onSelectAthlete,
  onAddAthlete,
  teams,
  onAddTeam,
  activeSidebarTab,
  setActiveSidebarTab,
  selectedTeamId,
  setSelectedTeamId
}) => {
  const [isAddingAthlete, setIsAddingAthlete] = useState(false);
  const [isAddingTeam, setIsAddingTeam] = useState(false);
  const [newAthleteName, setNewAthleteName] = useState('');
  const [newTeamName, setNewTeamName] = useState('');

  const handleAddAthlete = () => {
    if (newAthleteName.trim()) {
      onAddAthlete(newAthleteName.trim(), selectedTeamId || undefined);
      setNewAthleteName('');
      setIsAddingAthlete(false);
    }
  };

  const handleAddTeam = () => {
    if (newTeamName.trim()) {
      onAddTeam(newTeamName.trim());
      setNewTeamName('');
      setIsAddingTeam(false);
    }
  };

  const handleKeyPressTeam = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddTeam();
    } else if (e.key === 'Escape') {
      setIsAddingTeam(false);
      setNewTeamName('');
    }
  };
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAddAthlete();
    } else if (e.key === 'Escape') {
      setIsAddingAthlete(false);
      setNewAthleteName('');
    }
  };

  // Get athletes for current context
  const getAthletesForCurrentContext = () => {
    if (activeSidebarTab === 'teams' && selectedTeamId) {
      return athletes.filter(athlete => athlete.teamId === selectedTeamId);
    }
    if (activeSidebarTab === 'athletes') {
      return athletes;
    }
    return [];
  };

  const currentAthletes = getAthletesForCurrentContext();
  const selectedTeam = teams.find(team => team.id === selectedTeamId);

  return (
    <div className="bg-gray-800 rounded-xl shadow-lg p-4">
      {/* Tab Header */}
      <div className="mb-4">
        <div className="flex rounded-lg bg-gray-700 p-1 mb-3">
          <button
            onClick={() => {
              setActiveSidebarTab('athletes');
              setSelectedTeamId(null);
            }}
            className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              activeSidebarTab === 'athletes'
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Athletes</span>
          </button>
          <button
            onClick={() => setActiveSidebarTab('teams')}
            className={`flex-1 flex items-center justify-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
              activeSidebarTab === 'teams'
                ? 'bg-blue-600 text-white'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Teams</span>
          </button>
        </div>

        {/* Dynamic Header and Add Button */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {activeSidebarTab === 'teams' && selectedTeamId ? (
              <>
                <button
                  onClick={() => setSelectedTeamId(null)}
                  className="p-1 text-gray-400 hover:text-gray-200 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <UserCheck className="w-5 h-5 text-green-400" />
                <h3 className="font-semibold text-gray-100">{selectedTeam?.name}</h3>
              </>
            ) : (
              <>
                {activeSidebarTab === 'athletes' ? (
                  <User className="w-5 h-5 text-blue-400" />
                ) : (
                  <Users className="w-5 h-5 text-purple-400" />
                )}
                <h3 className="font-semibold text-gray-100">
                  {activeSidebarTab === 'athletes' ? 'All Athletes' : 'Teams'}
                </h3>
              </>
            )}
          </div>
          <button
            onClick={() => {
              if (activeSidebarTab === 'athletes' || selectedTeamId) {
                setIsAddingAthlete(true);
              } else {
                setIsAddingTeam(true);
              }
            }}
            className="p-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2">
        {/* Content based on active tab and context */}
        {activeSidebarTab === 'athletes' || selectedTeamId ? (
          // Show athletes (either all or team-specific)
          <>
            {currentAthletes.map((athlete) => (
              <button
                key={athlete.id}
                onClick={() => onSelectAthlete(athlete.id)}
                className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${
                  selectedAthleteId === athlete.id
                    ? 'bg-blue-600 text-white border border-blue-500'
                    : 'text-gray-300 hover:bg-gray-700 border border-transparent'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  selectedAthleteId === athlete.id
                    ? 'bg-blue-500'
                    : 'bg-gray-600'
                }`}>
                  <User className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{athlete.name}</p>
                  <div className="flex items-center space-x-2 text-xs opacity-75">
                    <Activity className="w-3 h-3" />
                    <span>{athlete.sessions.length} sessions</span>
                    {activeSidebarTab === 'athletes' && athlete.teamId && (
                      <>
                        <span>•</span>
                        <span>{teams.find(t => t.id === athlete.teamId)?.name}</span>
                      </>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </>
        ) : (
          // Show teams
          <>
            {teams.map((team) => {
              const teamAthletes = athletes.filter(athlete => athlete.teamId === team.id);
              return (
                <button
                  key={team.id}
                  onClick={() => setSelectedTeamId(team.id)}
                  className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors text-gray-300 hover:bg-gray-700 border border-transparent"
                >
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-purple-600">
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{team.name}</p>
                    <div className="flex items-center space-x-2 text-xs opacity-75">
                      <UserCheck className="w-3 h-3" />
                      <span>{teamAthletes.length} athletes</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </>
        )}

        {/* Add Athlete Form */}
        {isAddingAthlete && (
          <div className="mt-3 p-3 bg-gray-700 rounded-lg border border-gray-600">
            <input
              type="text"
              value={newAthleteName}
              onChange={(e) => setNewAthleteName(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={`Enter athlete name${selectedTeamId ? ` for ${selectedTeam?.name}` : ''}...`}
              className="w-full px-3 py-2 bg-gray-800 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              autoFocus
            />
            <div className="flex justify-end space-x-2 mt-2">
              <button
                onClick={() => {
                  setIsAddingAthlete(false);
                  setNewAthleteName('');
                }}
                className="px-3 py-1 text-xs text-gray-400 hover:text-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddAthlete}
                disabled={!newAthleteName.trim()}
                className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add
              </button>
            </div>
          </div>
        )}

        {/* Add Team Form */}
        {isAddingTeam && (
          <div className="mt-3 p-3 bg-gray-700 rounded-lg border border-gray-600">
            <input
              type="text"
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              onKeyDown={handleKeyPressTeam}
              placeholder="Enter team name..."
              className="w-full px-3 py-2 bg-gray-800 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              autoFocus
            />
            <div className="flex justify-end space-x-2 mt-2">
              <button
                onClick={() => {
                  setIsAddingTeam(false);
                  setNewTeamName('');
                }}
                className="px-3 py-1 text-xs text-gray-400 hover:text-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddTeam}
                disabled={!newTeamName.trim()}
                className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add
              </button>
            </div>
          </div>
        )}

        {/* Empty States */}
        {activeSidebarTab === 'athletes' && currentAthletes.length === 0 && !isAddingAthlete && (
          <div className="text-center py-8">
            <Users className="w-8 h-8 text-gray-500 mx-auto mb-2" />
            <p className="text-sm text-gray-400">No athletes{selectedTeamId ? ' in this team' : ''} yet</p>
            <p className="text-xs text-gray-500">Click + to add{selectedTeamId ? ' an athlete to this team' : ' your first athlete'}</p>
          </div>
        )}

        {activeSidebarTab === 'teams' && !selectedTeamId && teams.length === 0 && !isAddingTeam && (
          <div className="text-center py-8">
            <Users className="w-8 h-8 text-gray-500 mx-auto mb-2" />
            <p className="text-sm text-gray-400">No teams yet</p>
            <p className="text-xs text-gray-500">Click + to create your first team</p>
          </div>
        )}
      </div>
    </div>
  );
};