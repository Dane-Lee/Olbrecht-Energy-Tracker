import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUp, TrendingDown, Activity, Target, Clock, Zap } from 'lucide-react';
import { TrainingSession } from '../types/training';
import { formatTime } from '../utils/olbrechtCalculations';

interface PerformanceDashboardProps {
  sessions: TrainingSession[];
  timeframe: 'week' | 'month' | 'season';
}

export const PerformanceDashboard: React.FC<PerformanceDashboardProps> = ({ 
  sessions, 
  timeframe 
}) => {
  // Filter sessions based on timeframe
  const getFilteredSessions = () => {
    const now = new Date();
    const cutoffDate = new Date();
    
    switch (timeframe) {
      case 'week':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        cutoffDate.setMonth(now.getMonth() - 1);
        break;
      case 'season':
        cutoffDate.setMonth(now.getMonth() - 6);
        break;
    }
    
    return sessions.filter(session => new Date(session.date) >= cutoffDate);
  };

  const filteredSessions = getFilteredSessions();

  // Process sessions for charts
  const processedData = filteredSessions
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(session => ({
      date: new Date(session.date).toLocaleDateString(),
      volume: session.totalDistance,
      intensity: session.averageIntensity * 100,
      tss: session.trainingLoad.trainingStressScore,
      aerobic: session.energySystemContribution.aerobic,
      anaerobicLactic: session.energySystemContribution.anaerobicLactic,
      anaerobicAlactic: session.energySystemContribution.anaerobicAlactic
    }));

  // Calculate summary statistics
  const totalVolume = filteredSessions.reduce((sum, session) => sum + session.totalDistance, 0);
  const totalTime = filteredSessions.reduce((sum, session) => sum + session.totalTime, 0);
  const avgIntensity = filteredSessions.length > 0 
    ? filteredSessions.reduce((sum, session) => sum + session.averageIntensity, 0) / filteredSessions.length 
    : 0;
  const totalTSS = filteredSessions.reduce((sum, session) => sum + session.trainingLoad.trainingStressScore, 0);
  
  // Calculate monotony and strain
  const avgTSS = filteredSessions.length > 0 ? totalTSS / filteredSessions.length : 0;
  const tssValues = filteredSessions.map(s => s.trainingLoad.trainingStressScore);
  const tssStdDev = tssValues.length > 1 ? Math.sqrt(tssValues.reduce((sum, val) => sum + Math.pow(val - avgTSS, 2), 0) / tssValues.length) : 1;
  const monotony = tssStdDev > 0 ? avgTSS / tssStdDev : 1;
  const strain = totalTSS * monotony;

  // Calculate trends (simplified)
  const volumeTrend = processedData.length > 1 
    ? ((processedData[processedData.length - 1].volume - processedData[0].volume) / processedData[0].volume) * 100
    : 0;

  const intensityTrend = processedData.length > 1
    ? ((processedData[processedData.length - 1].intensity - processedData[0].intensity) / processedData[0].intensity) * 100
    : 0;

  const StatCard = ({ 
    title, 
    value, 
    unit, 
    trend, 
    icon: Icon, 
    color 
  }: {
    title: string;
    value: string | number;
    unit: string;
    trend?: number;
    icon: any;
    color: string;
  }) => (
    <div className="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-100">
            {value} <span className="text-sm font-normal text-gray-400">{unit}</span>
          </p>
        </div>
        <div className={`p-3 rounded-full ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      {trend !== undefined && (
        <div className="mt-4 flex items-center">
          {trend >= 0 ? (
            <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
          )}
          <span className={`text-sm font-medium ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {Math.abs(trend).toFixed(1)}%
          </span>
          <span className="text-sm text-gray-400 ml-1">vs last period</span>
        </div>
      )}
    </div>
  );

  if (sessions.length === 0) {
    return (
      <div className="text-center py-12">
        <Activity className="w-16 h-16 text-gray-500 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-200 mb-2">No training data available</h3>
        <p className="text-gray-400">Add some training sessions to see performance analytics.</p>
      </div>
    );
  }

  if (filteredSessions.length === 0) {
    return (
      <div className="text-center py-12">
        <Activity className="w-16 h-16 text-gray-500 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-200 mb-2">No data for selected timeframe</h3>
        <p className="text-gray-400">Try selecting a different timeframe or add more training sessions.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <StatCard
          title="Total Volume"
          value={totalVolume.toLocaleString()}
          unit="m"
          trend={volumeTrend}
          icon={Activity}
          color="bg-blue-500"
        />
        <StatCard
          title="Total Time"
          value={formatTime(totalTime)}
          unit=""
          icon={Clock}
          color="bg-green-500"
        />
        <StatCard
          title="Avg Intensity"
          value={(avgIntensity * 100).toFixed(0)}
          unit="% CV"
          trend={intensityTrend}
          icon={Target}
          color="bg-purple-500"
        />
        <StatCard
          title="Training Load"
          value={totalTSS.toFixed(0)}
          unit="TSS"
          icon={Zap}
          color="bg-orange-500"
        />
        <StatCard
          title="Monotony"
          value={monotony.toFixed(1)}
          unit=""
          icon={TrendingUp}
          color="bg-yellow-500"
        />
        <StatCard
          title="Strain"
          value={strain.toFixed(0)}
          unit=""
          icon={TrendingDown}
          color="bg-red-500"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Volume and Intensity Trend */}
        <div className="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
          <h3 className="text-lg font-semibold mb-4 text-gray-100">Training Volume & Intensity</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={processedData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" />
              <YAxis yAxisId="left" stroke="#9CA3AF" />
              <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#F3F4F6'
                }}
              />
              <Bar yAxisId="left" dataKey="volume" fill="#3B82F6" opacity={0.3} />
              <Line 
                yAxisId="right" 
                type="monotone" 
                dataKey="intensity" 
                stroke="#EF4444" 
                strokeWidth={2}
                dot={{ fill: '#EF4444', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Energy System Distribution */}
        <div className="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
          <h3 className="text-lg font-semibold mb-4 text-gray-100">Energy System Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={processedData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1F2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#F3F4F6'
                }}
              />
              <Bar dataKey="aerobic" stackId="a" fill="#3B82F6" />
              <Bar dataKey="anaerobicLactic" stackId="a" fill="#EF4444" />
              <Bar dataKey="anaerobicAlactic" stackId="a" fill="#10B981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Training Stress Score Trend */}
      <div className="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
        <h3 className="text-lg font-semibold mb-4 text-gray-100">Training Stress Score Trend</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={processedData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9CA3AF" />
            <YAxis stroke="#9CA3AF" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1F2937', 
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#F3F4F6'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="tss" 
              stroke="#8B5CF6" 
              strokeWidth={2}
              dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};