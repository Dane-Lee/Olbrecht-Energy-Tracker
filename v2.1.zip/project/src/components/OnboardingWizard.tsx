import React, { useState } from 'react';
import { Activity, BarChart3, Users, Target, Zap, Clock } from 'lucide-react';
import { AthleteSelector } from './AthleteSelector';
import { Athlete } from '../types/athlete';
import { Team } from '../types/team';

interface OnboardingWizardProps {
  athletes: Athlete[];
  teams: Team[];
  selectedAthleteId: string | null;
  onSelectAthlete: (athleteId: string) => void;
  onAddAthlete: (name: string, teamId?: string) => void;
  onAddTeam: (name: string) => void;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({
  athletes,
  teams,
  selectedAthleteId,
  onSelectAthlete,
  onAddAthlete,
  onAddTeam
}) => {
  const [activeSidebarTab, setActiveSidebarTab] = useState<'athletes' | 'teams'>('athletes');
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  const features = [
    {
      icon: Users,
      title: 'Multi-Athlete Management',
      description: 'Create separate profiles for individual swimmers or team members. Each athlete gets their own data folder with complete training history.',
      color: 'bg-blue-500'
    },
    {
      icon: BarChart3,
      title: 'Energy System Analysis',
      description: 'Analyze aerobic, anaerobic lactic, and anaerobic alactic energy contributions based on Olbrecht\'s lactate-driven methodology.',
      color: 'bg-purple-500'
    },
    {
      icon: Target,
      title: 'Training Load Monitoring',
      description: 'Track training stress scores (TSS), recovery times, and session intensity to optimize training periodization.',
      color: 'bg-green-500'
    },
    {
      icon: Clock,
      title: 'Performance Tracking',
      description: 'Record detailed training sessions with sets, repetitions, times, and monitor progress over time with comprehensive dashboards.',
      color: 'bg-orange-500'
    },
    {
      icon: Zap,
      title: 'Physiological Profiling',
      description: 'Maintain critical velocity, anaerobic capacity, and other key parameters. Ready for integration with companion swim test data.',
      color: 'bg-red-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <header className="bg-gray-800 shadow-lg border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-100">Olbrecht Energy Tracker</h1>
                <p className="text-sm text-gray-400">Elite Swimming Performance Analysis</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Activity className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-100 mb-4">
            <span className="text-3xl block">Welcome to</span>
            <span className="text-5xl block">The Olbrecht</span>
            <span className="text-2xl block italic">Swimming Energy Tracker</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            A sophisticated training analysis system based on Jan Olbrecht's lactate-driven methodology.
            <br />
            Performance optimization through precise energy system modeling and training load management.
          </p>
          <button
            onClick={() => {
              const getStartedSection = document.getElementById('get-started-section');
              if (getStartedSection) {
                getStartedSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-lg font-semibold mb-8 inline-flex items-center space-x-2"
          >
            <span>Get Started</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </button>
          <div className="bg-blue-900/30 border border-blue-700/50 rounded-xl p-6 max-w-4xl mx-auto">
            <h2 className="text-lg font-semibold text-blue-200 mb-2">
              Professional Swimming Performance Analysis
            </h2>
            <p className="text-blue-100">
              This system provides the same level of analysis used by elite coaches and sports scientists. 
              Track multiple athletes, analyze energy system contributions, and optimize training loads with scientific precision.
            </p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-100 text-center mb-8">
            Core Capabilities
          </h2>
          <div className="flex flex-wrap justify-center gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="bg-gray-800 rounded-xl border border-gray-700 p-6 hover:bg-gray-750 transition-colors text-center w-full md:w-80 lg:w-80">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4 mx-auto`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-100 mb-2">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* How It Works */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-100 text-center mb-8">
            How It Works
          </h2>
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-gray-100 mb-4">The Olbrecht Method</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">1</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Physiological Profiling</h4>
                      <p className="text-gray-400 text-sm">Each athlete's critical velocity and anaerobic capacity define their unique energy system model.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">2</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Training Analysis</h4>
                      <p className="text-gray-400 text-sm">Every swim is analyzed for aerobic and anaerobic energy contributions based on distance and time.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">3</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Load Quantification</h4>
                      <p className="text-gray-400 text-sm">Training stress is calculated to optimize adaptation while preventing overtraining.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-100 mb-4">Your Workflow</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">1</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Create Athlete Profiles</h4>
                      <p className="text-gray-400 text-sm">Set up individual folders for each swimmer with their physiological parameters.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">2</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Log Training Sessions</h4>
                      <p className="text-gray-400 text-sm">Input sets, distances, and times from each training session.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-sm font-bold mt-0.5">3</div>
                    <div>
                      <h4 className="font-medium text-gray-200">Monitor & Optimize</h4>
                      <p className="text-gray-400 text-sm">View energy system analysis and adjust training based on scientific insights.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Note */}
        <div className="mb-12">
          <div className="bg-purple-900/30 border border-purple-700/50 rounded-xl p-6 text-center">
            <Zap className="w-8 h-8 text-purple-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-purple-200 mb-2">
              Companion App Integration
            </h3>
            <p className="text-purple-100 max-w-2xl mx-auto">
              This system accepts physiological data from swim test apps, lactate analyzers, and fitness devices 
              for maximum accuracy. Integration options include API connections, file imports, and manual input. 
              Start with default values and upgrade to automated data as your testing capabilities expand.
            </p>
          </div>
        </div>

        {/* Get Started Section */}
        <div id="get-started-section" className="text-center">
          <h2 className="text-2xl font-bold text-gray-100 mb-6">
            Get Started
          </h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Create your first athlete profile to begin tracking training sessions and analyzing performance. 
            Each athlete gets their own independent data folder.
          </p>
          
          <div className="max-w-md mx-auto">
            <AthleteSelector
              athletes={athletes}
              teams={teams}
              selectedAthleteId={selectedAthleteId}
              onSelectAthlete={onSelectAthlete}
              onAddAthlete={onAddAthlete}
              onAddTeam={onAddTeam}
              activeSidebarTab={activeSidebarTab}
              setActiveSidebarTab={setActiveSidebarTab}
              selectedTeamId={selectedTeamId}
              setSelectedTeamId={setSelectedTeamId}
            />
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            Start by clicking the + button above to create your first athlete profile
          </p>
        </div>
      </div>
    </div>
  );
};