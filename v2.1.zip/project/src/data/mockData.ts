// Empty data for first-time use
export const mockAthletes: any[] = [];

// For backward compatibility, export empty defaults
export const mockAthlete = null;
export const mockSessions: any[] = [];