import { supabase } from '../lib/supabase';
import { Athlete, PhysiologicalProfile } from '../types/athlete';
import { Team } from '../types/team';
import { TrainingSession, TrainingSet } from '../types/training';
import { Database } from '../types/database';

// Type aliases for database rows
type AthleteRow = Database['public']['Tables']['athletes']['Row'];
type PhysiologicalProfileRow = Database['public']['Tables']['physiological_profiles']['Row'];
type TeamRow = Database['public']['Tables']['teams']['Row'];
type TrainingSessionRow = Database['public']['Tables']['training_sessions']['Row'];
type TrainingSetRow = Database['public']['Tables']['training_sets']['Row'];

export class DatabaseService {
  // Teams
  static async getAllTeams(): Promise<Team[]> {
    const { data, error } = await supabase
      .from('teams')
      .select('*')
      .order('name');

    if (error) throw error;
    
    return data.map(team => ({
      id: team.id,
      name: team.name,
      createdAt: team.created_at,
      updatedAt: team.updated_at
    }));
  }

  static async createTeam(name: string): Promise<Team> {
    const { data, error } = await supabase
      .from('teams')
      .insert({ name })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      name: data.name,
      createdAt: data.created_at,
      updatedAt: data.updated_at
    };
  }

  // Athletes
  static async getAllAthletes(): Promise<Athlete[]> {
    const { data, error } = await supabase
      .from('athletes')
      .select(`
        *,
        physiological_profiles!athletes_physiological_profile_id_fkey (*),
        training_sessions (
          *,
          training_sets (*)
        )
      `)
      .order('name');

    if (error) throw error;

    return data.map(athleteRow => this.mapAthleteFromDatabase(athleteRow));
  }

  static async getAthleteById(id: string): Promise<Athlete | null> {
    const { data, error } = await supabase
      .from('athletes')
      .select(`
        *,
        physiological_profiles!athletes_physiological_profile_id_fkey (*),
        training_sessions (
          *,
          training_sets (*)
        )
      `)
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') return null; // No rows returned
      throw error;
    }

    return this.mapAthleteFromDatabase(data);
  }

  static async createAthlete(athleteData: {
    name: string;
    email?: string;
    dateOfBirth: string;
    gender: 'male' | 'female';
    specialtyDistance: number;
    specialtyStroke: string;
    specialtyRaceType: string;
    teamId?: string;
    physiologicalProfile: PhysiologicalProfile;
  }): Promise<Athlete> {
    // First create the athlete without physiological profile
    const { data: athleteRow, error: athleteError } = await supabase
      .from('athletes')
      .insert({
        name: athleteData.name,
        email: athleteData.email,
        date_of_birth: athleteData.dateOfBirth,
        gender: athleteData.gender,
        specialty_distance: athleteData.specialtyDistance,
        specialty_stroke: athleteData.specialtyStroke,
        specialty_race_type: athleteData.specialtyRaceType,
        team_id: athleteData.teamId,
        personal_bests: {}
      })
      .select()
      .single();

    if (athleteError) throw athleteError;

    // Then create the physiological profile with athlete_id
    const { data: profileData, error: profileError } = await supabase
      .from('physiological_profiles')
      .insert({
        athlete_id: athleteRow.id,
        critical_velocity: athleteData.physiologicalProfile.criticalVelocity,
        anaerobic_capacity: athleteData.physiologicalProfile.anaerobicCapacity,
        aerobic_power: athleteData.physiologicalProfile.aerobicPower,
        lactate_threshold: athleteData.physiologicalProfile.lactateThreshold,
        max_lactate: athleteData.physiologicalProfile.maxLactate,
        recovery_rate: athleteData.physiologicalProfile.recoveryRate,
        estimated_vo2_max: athleteData.physiologicalProfile.estimatedVO2Max,
        resting_heart_rate: athleteData.physiologicalProfile.restingHeartRate,
        max_heart_rate: athleteData.physiologicalProfile.maxHeartRate
      })
      .select()
      .single();

    if (profileError) throw profileError;

    // Finally, update the athlete with the physiological profile ID
    const { error: updateError } = await supabase
      .from('athletes')
      .update({ physiological_profile_id: profileData.id })
      .eq('id', athleteRow.id);

    if (updateError) throw updateError;

    // Return the complete athlete object
    return {
      id: athleteRow.id,
      name: athleteRow.name,
      email: athleteRow.email || '',
      dateOfBirth: athleteRow.date_of_birth,
      gender: athleteRow.gender,
      specialtyDistance: athleteRow.specialty_distance,
      specialtyStroke: athleteRow.specialty_stroke,
      specialtyRaceType: athleteRow.specialty_race_type,
      personalBests: athleteRow.personal_bests || {},
      physiologicalProfile: {
        criticalVelocity: profileData.critical_velocity,
        anaerobicCapacity: profileData.anaerobic_capacity,
        aerobicPower: profileData.aerobic_power,
        lactateThreshold: profileData.lactate_threshold,
        maxLactate: profileData.max_lactate,
        recoveryRate: profileData.recovery_rate,
        estimatedVO2Max: profileData.estimated_vo2_max,
        restingHeartRate: profileData.resting_heart_rate,
        maxHeartRate: profileData.max_heart_rate
      },
      sessions: [],
      teamId: athleteRow.team_id,
      createdAt: athleteRow.created_at,
      updatedAt: athleteRow.updated_at
    };
  }

  static async updateAthlete(id: string, updates: Partial<Athlete>): Promise<void> {
    const { error } = await supabase
      .from('athletes')
      .update({
        name: updates.name,
        email: updates.email,
        date_of_birth: updates.dateOfBirth,
        gender: updates.gender,
        specialty_distance: updates.specialtyDistance,
        specialty_stroke: updates.specialtyStroke,
        specialty_race_type: updates.specialtyRaceType,
        team_id: updates.teamId,
        personal_bests: updates.personalBests,
        updated_at: new Date().toISOString()
      })
      .eq('id', id);

    if (error) throw error;
  }

  static async updatePhysiologicalProfile(athleteId: string, profile: PhysiologicalProfile): Promise<void> {
    const { error } = await supabase
      .from('physiological_profiles')
      .update({
        critical_velocity: profile.criticalVelocity,
        anaerobic_capacity: profile.anaerobicCapacity,
        aerobic_power: profile.aerobicPower,
        lactate_threshold: profile.lactateThreshold,
        max_lactate: profile.maxLactate,
        recovery_rate: profile.recoveryRate,
        estimated_vo2_max: profile.estimatedVO2Max,
        resting_heart_rate: profile.restingHeartRate,
        max_heart_rate: profile.maxHeartRate,
        updated_at: new Date().toISOString()
      })
      .eq('athlete_id', athleteId);

    if (error) throw error;
  }

  // Training Sessions
  static async createTrainingSession(
    athleteId: string, 
    sessionData: Omit<TrainingSession, 'id' | 'createdAt'>
  ): Promise<TrainingSession> {
    // First create the training session
    const { data: sessionRow, error: sessionError } = await supabase
      .from('training_sessions')
      .insert({
        athlete_id: athleteId,
        date: sessionData.date,
        session_type: sessionData.sessionType,
        total_distance: sessionData.totalDistance,
        total_time: sessionData.totalTime,
        average_intensity: sessionData.averageIntensity,
        energy_system_contribution: sessionData.energySystemContribution,
        training_load: sessionData.trainingLoad,
        notes: sessionData.notes
      })
      .select()
      .single();

    if (sessionError) throw sessionError;

    // Then create the training sets
    const setsToInsert = sessionData.sets.map(set => ({
      session_id: sessionRow.id,
      distance: set.distance,
      repetitions: set.repetitions,
      times: set.times,
      rest_interval: set.restInterval,
      stroke_rate: set.strokeRate,
      heart_rate: set.heartRate,
      perceived_exertion: set.perceivedExertion,
      lactate_values: set.lactateValues
    }));

    const { data: setsData, error: setsError } = await supabase
      .from('training_sets')
      .insert(setsToInsert)
      .select();

    if (setsError) throw setsError;

    // Return the complete session with sets
    return {
      id: sessionRow.id,
      date: sessionRow.date,
      sessionType: sessionRow.session_type,
      totalDistance: sessionRow.total_distance,
      totalTime: sessionRow.total_time,
      averageIntensity: sessionRow.average_intensity,
      energySystemContribution: sessionRow.energy_system_contribution,
      trainingLoad: sessionRow.training_load,
      notes: sessionRow.notes,
      sets: setsData.map(set => ({
        id: set.id,
        distance: set.distance,
        repetitions: set.repetitions,
        times: set.times,
        restInterval: set.rest_interval,
        strokeRate: set.stroke_rate,
        heartRate: set.heart_rate,
        perceivedExertion: set.perceived_exertion,
        lactateValues: set.lactate_values
      })),
      createdAt: sessionRow.created_at
    };
  }

  // Helper method to map database rows to our application types
  private static mapAthleteFromDatabase(data: any): Athlete {
    const sessions: TrainingSession[] = data.training_sessions?.map((session: any) => ({
      id: session.id,
      date: session.date,
      sessionType: session.session_type,
      totalDistance: session.total_distance,
      totalTime: session.total_time,
      averageIntensity: session.average_intensity,
      energySystemContribution: session.energy_system_contribution,
      trainingLoad: session.training_load,
      notes: session.notes,
      sets: session.training_sets?.map((set: any) => ({
        id: set.id,
        distance: set.distance,
        repetitions: set.repetitions,
        times: set.times,
        restInterval: set.rest_interval,
        strokeRate: set.stroke_rate,
        heartRate: set.heart_rate,
        perceivedExertion: set.perceived_exertion,
        lactateValues: set.lactate_values
      })) || [],
      createdAt: session.created_at
    })) || [];

    const physiologicalProfile = data.physiological_profiles ? {
      criticalVelocity: data.physiological_profiles.critical_velocity,
      anaerobicCapacity: data.physiological_profiles.anaerobic_capacity,
      aerobicPower: data.physiological_profiles.aerobic_power,
      lactateThreshold: data.physiological_profiles.lactate_threshold,
      maxLactate: data.physiological_profiles.max_lactate,
      recoveryRate: data.physiological_profiles.recovery_rate,
      estimatedVO2Max: data.physiological_profiles.estimated_vo2_max,
      restingHeartRate: data.physiological_profiles.resting_heart_rate,
      maxHeartRate: data.physiological_profiles.max_heart_rate
    } : {
      criticalVelocity: 1.40,
      anaerobicCapacity: 25.0,
      aerobicPower: 250,
      lactateThreshold: 4.0,
      maxLactate: 12.0,
      recoveryRate: 0.8,
      estimatedVO2Max: 50,
      restingHeartRate: 60,
      maxHeartRate: 190
    };

    return {
      id: data.id,
      name: data.name,
      email: data.email || '',
      dateOfBirth: data.date_of_birth,
      gender: data.gender,
      specialtyDistance: data.specialty_distance,
      specialtyStroke: data.specialty_stroke,
      specialtyRaceType: data.specialty_race_type,
      personalBests: data.personal_bests || {},
      physiologicalProfile,
      sessions,
      teamId: data.team_id,
      profilePicture: data.profile_picture,
      createdAt: data.created_at,
      updatedAt: data.updated_at
    };
  }
}