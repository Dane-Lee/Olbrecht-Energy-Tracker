import React, { useState, useEffect } from 'react';
import { Activity, Plus, User, BarChart3, Calendar } from 'lucide-react';
import { AthleteProfile } from './components/AthleteProfile';
import { AthleteSelector } from './components/AthleteSelector';
import { OnboardingWizard } from './components/OnboardingWizard';
import { TrainingSessionForm } from './components/TrainingSessionForm';
import { SessionList } from './components/SessionList';
import { PerformanceDashboard } from './components/PerformanceDashboard';
import { EnergySystemChart } from './components/EnergySystemChart';
import { DatabaseService } from './services/database';
import { Athlete, PhysiologicalProfile } from './types/athlete';
import { Team } from './types/team';
import { TrainingSession } from './types/training';

type View = 'dashboard' | 'sessions' | 'profile' | 'add-session';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [athletes, setAthletes] = useState<Athlete[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [selectedAthleteId, setSelectedAthleteId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeSidebarTab, setActiveSidebarTab] = useState<'athletes' | 'teams'>('athletes');
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);
  const [dashboardTimeframe, setDashboardTimeframe] = useState<'week' | 'month' | 'season'>('week');

  const selectedAthlete = athletes.find(a => a.id === selectedAthleteId) || null;
  const currentSessions = selectedAthlete?.sessions || [];

  // Load initial data
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const [athletesData, teamsData] = await Promise.all([
          DatabaseService.getAllAthletes(),
          DatabaseService.getAllTeams()
        ]);
        
        setAthletes(athletesData);
        setTeams(teamsData);
        
        // Auto-select first athlete if available
        if (athletesData.length > 0 && !selectedAthleteId) {
          setSelectedAthleteId(athletesData[0].id);
        }
      } catch (err) {
        console.error('Error loading data:', err);
        const errorMessage = err instanceof Error ? err.message : 'Failed to load data. Please try refreshing the page.';
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  // Reload athlete data when selection changes
  useEffect(() => {
    if (selectedAthleteId && !athletes.find(a => a.id === selectedAthleteId)) {
      const loadAthlete = async () => {
        try {
          const athlete = await DatabaseService.getAthleteById(selectedAthleteId);
          if (athlete) {
            setAthletes(prev => [...prev.filter(a => a.id !== selectedAthleteId), athlete]);
          }
        } catch (err) {
          console.error('Error loading athlete:', err);
          const errorMessage = err instanceof Error ? err.message : 'Failed to load athlete';
          setError(errorMessage);
        }
      };
      loadAthlete();
    }
  }, [selectedAthleteId]);

  const handleSelectAthlete = (athleteId: string) => {
    setSelectedAthleteId(athleteId);
    setCurrentView('dashboard');
  };

  const handleAddAthlete = async (name: string, teamId?: string) => {
    try {
      const newAthlete = await DatabaseService.createAthlete({
        name,
        dateOfBirth: '2000-01-01',
        gender: 'male',
        specialtyDistance: 100,
        specialtyStroke: 'freestyle',
        specialtyRaceType: 'sprint',
        teamId,
        physiologicalProfile: {
          criticalVelocity: 1.40,
          anaerobicCapacity: 25.0,
          aerobicPower: 250,
          lactateThreshold: 4.0,
          maxLactate: 12.0,
          recoveryRate: 0.8,
          estimatedVO2Max: 50,
          restingHeartRate: 60,
          maxHeartRate: 190
        }
      });
      
      setAthletes(prev => [...prev, newAthlete]);
      setSelectedAthleteId(newAthlete.id);
    } catch (err) {
      console.error('Error creating athlete:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to create athlete. Please try again.';
      setError(errorMessage);
    }
  };

  const handleAddTeam = async (name: string) => {
    try {
      const newTeam = await DatabaseService.createTeam(name);
      setTeams(prev => [...prev, newTeam]);
    } catch (err) {
      console.error('Error creating team:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to create team. Please try again.';
      setError(errorMessage);
    }
  };

  const handleUpdateAthlete = async (updatedProfile: PhysiologicalProfile) => {
    if (!selectedAthlete) return;
    
    try {
      await DatabaseService.updatePhysiologicalProfile(selectedAthlete.id, updatedProfile);
      
      // Update local state
      const updatedAthlete: Athlete = {
        ...selectedAthlete,
        physiologicalProfile: updatedProfile,
        updatedAt: new Date().toISOString()
      };
      
      setAthletes(prev => prev.map(a => 
        a.id === selectedAthlete.id ? updatedAthlete : a
      ));
    } catch (err) {
      console.error('Error updating physiological profile:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to update profile. Please try again.';
      setError(errorMessage);
    }
  };

  const handleUpdateAthleteInfo = async (athleteData: Partial<Athlete>) => {
    if (!selectedAthlete) return;
    
    try {
      await DatabaseService.updateAthlete(selectedAthlete.id, athleteData);
      
      // Update local state
      const updatedAthlete: Athlete = {
        ...selectedAthlete,
        ...athleteData,
        updatedAt: new Date().toISOString()
      };
      
      setAthletes(prev => prev.map(a => 
        a.id === selectedAthlete.id ? updatedAthlete : a
      ));
    } catch (err) {
      console.error('Error updating athlete:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to update athlete. Please try again.';
      setError(errorMessage);
    }
  };

  const handleSaveSession = async (sessionData: Omit<TrainingSession, 'id' | 'createdAt'>) => {
    if (!selectedAthlete) return;
    
    try {
      const newSession = await DatabaseService.createTrainingSession(selectedAthlete.id, sessionData);
      
      // Update local state
      const updatedAthlete: Athlete = {
        ...selectedAthlete,
        sessions: [...selectedAthlete.sessions, newSession],
        updatedAt: new Date().toISOString()
      };
      
      setAthletes(prev => prev.map(a => 
        a.id === selectedAthlete.id ? updatedAthlete : a
      ));
      setCurrentView('sessions');
    } catch (err) {
      console.error('Error saving session:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to save training session. Please try again.';
      setError(errorMessage);
    }
  };

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'sessions', label: 'Sessions', icon: Calendar },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-100 mb-4">Loading...</h2>
          <p className="text-gray-400">Setting up your training data...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 bg-red-600 rounded-xl flex items-center justify-center mx-auto mb-6">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-100 mb-4">Error</h2>
          <p className="text-gray-400 mb-6">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // Show onboarding if no athletes
  if (athletes.length === 0) {
    return (
      <OnboardingWizard
        athletes={athletes}
        teams={teams}
        selectedAthleteId={selectedAthleteId}
        onSelectAthlete={handleSelectAthlete}
        onAddAthlete={handleAddAthlete}
        onAddTeam={handleAddTeam}
      />
    );
  }

  // Show athlete selection if no athlete is selected
  if (!selectedAthlete) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-6">
            <User className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-100 mb-4">Select an Athlete</h2>
          <p className="text-gray-400 mb-8">Choose an athlete from the sidebar to view their data.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Error banner */}
      {error && (
        <div className="bg-red-600 text-white px-4 py-3 text-center">
          <span>{error}</span>
          <button
            onClick={() => setError(null)}
            className="ml-4 underline hover:no-underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Header */}
      <header className="bg-gray-800 shadow-lg border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-100">
                  The Olbrecht
                </h1>
                <p className="text-lg font-semibold text-gray-200">Swimming Energy Tracker</p>
                <p className="text-sm text-gray-400">Elite Performance Analysis</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-300">Current Athlete</p>
                <p className="font-semibold text-gray-100">{selectedAthlete.name}</p>
              </div>
              <button
                onClick={() => setCurrentView('add-session')}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Session</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-80">
            {/* Athlete Selector */}
            <AthleteSelector
              athletes={athletes}
              selectedAthleteId={selectedAthleteId}
              onSelectAthlete={handleSelectAthlete}
              onAddAthlete={handleAddAthlete}
              teams={teams}
              onAddTeam={handleAddTeam}
              activeSidebarTab={activeSidebarTab}
              setActiveSidebarTab={setActiveSidebarTab}
              selectedTeamId={selectedTeamId}
              setSelectedTeamId={setSelectedTeamId}
            />

            {/* Navigation */}
            <nav className="bg-gray-800 rounded-xl shadow-lg p-4 mt-6">
              <ul className="space-y-2">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => setCurrentView(item.id as View)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                          currentView === item.id
                            ? 'bg-blue-600 text-white border border-blue-500'
                            : 'text-gray-300 hover:bg-gray-700'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </nav>

          </div>

          {/* Main Content */}
          <div className="flex-1">
            {currentView === 'dashboard' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-100">Performance Dashboard</h2>
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => setDashboardTimeframe('week')}
                      className={`px-3 py-1 text-sm rounded-lg ${dashboardTimeframe === 'week' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                    >
                      Week
                    </button>
                    <button 
                      onClick={() => setDashboardTimeframe('month')}
                      className={`px-3 py-1 text-sm rounded-lg ${dashboardTimeframe === 'month' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                    >
                      Month
                    </button>
                    <button 
                      onClick={() => setDashboardTimeframe('season')}
                      className={`px-3 py-1 text-sm rounded-lg ${dashboardTimeframe === 'season' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}
                    >
                      Season
                    </button>
                  </div>
                </div>
                <PerformanceDashboard sessions={currentSessions} timeframe={dashboardTimeframe} />
              </div>
            )}

            {currentView === 'sessions' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-100">Training Sessions</h2>
                  <button
                    onClick={() => setCurrentView('add-session')}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Session</span>
                  </button>
                </div>
                <SessionList sessions={currentSessions} onSelectSession={setSelectedSession} />
              </div>
            )}

            {currentView === 'profile' && selectedAthlete && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-100">Athlete Profile</h2>
                <AthleteProfile 
                  athlete={selectedAthlete} 
                  onUpdateProfile={handleUpdateAthlete} 
                  onUpdateAthlete={handleUpdateAthleteInfo}
                />
              </div>
            )}

            {currentView === 'add-session' && selectedAthlete && (
              <div className="space-y-6">
                <TrainingSessionForm
                  profile={selectedAthlete.physiologicalProfile}
                  onSave={handleSaveSession}
                  onCancel={() => setCurrentView('sessions')}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Session Detail Modal */}
      {selectedSession && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-gray-700">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-100">
                  Session Details - {new Date(selectedSession.date).toLocaleDateString()}
                </h2>
                <button
                  onClick={() => setSelectedSession(null)}
                  className="text-gray-400 hover:text-gray-200 text-2xl p-2 rounded-full bg-gray-700 hover:bg-gray-600 transition-colors"
                >
                  ✕
                </button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gray-200">Session Overview</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="font-medium capitalize text-gray-200">{selectedSession.sessionType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Distance:</span>
                      <span className="font-medium text-gray-200">{selectedSession.totalDistance}m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Total Time:</span>
                      <span className="font-medium text-gray-200">
                        {Math.floor(selectedSession.totalTime / 60)}:{(selectedSession.totalTime % 60).toFixed(0).padStart(2, '0')}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Average Intensity:</span>
                      <span className="font-medium text-gray-200">{(selectedSession.averageIntensity * 100).toFixed(0)}% CV</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Training Load:</span>
                      <span className="font-medium text-gray-200">{selectedSession.trainingLoad.trainingStressScore.toFixed(0)} TSS</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <EnergySystemChart 
                    energyContribution={selectedSession.energySystemContribution} 
                    size="medium"
                  />
                </div>
              </div>

              {selectedSession.notes && (
                <div className="mt-6 p-4 bg-gray-700 rounded-lg border border-gray-600">
                  <h4 className="font-medium text-gray-200 mb-2">Notes</h4>
                  <p className="text-gray-300">{selectedSession.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;