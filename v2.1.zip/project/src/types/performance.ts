export interface PerformanceMetrics {
  date: string;
  distance: number;
  time: number;
  velocity: number; // m/s
  pace: number; // seconds per 100m
  intensityZone: IntensityZone;
  energyContribution: EnergySystemContribution;
  efficiency: number; // velocity / energy expenditure
  fatigue: number; // 0-100 scale
}

export interface IntensityZone {
  zone: 1 | 2 | 3 | 4 | 5;
  name: string;
  description: string;
  percentageOfCV: number; // percentage of critical velocity
  lactateRange: [number, number]; // mmol/L range
}

export interface PerformanceTrend {
  metric: string;
  timeframe: 'week' | 'month' | 'season';
  trend: 'improving' | 'stable' | 'declining';
  changePercentage: number;
  confidence: number; // 0-1
}