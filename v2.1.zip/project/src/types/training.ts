export interface TrainingSession {
  id: string;
  date: string;
  sessionType: 'training' | 'competition' | 'test';
  sets: TrainingSet[];
  totalDistance: number;
  totalTime: number; // in seconds
  averageIntensity: number; // percentage of critical velocity
  energySystemContribution: EnergySystemContribution;
  trainingLoad: TrainingLoad;
  notes?: string;
  createdAt: string;
}

export interface TrainingSet {
  id: string;
  distance: number; // meters
  repetitions: number;
  times: number[]; // array of times in seconds for each rep
  restInterval: number; // seconds
  strokeRate?: number[];
  heartRate?: number[];
  perceivedExertion?: number[]; // 1-10 scale
  lactateValues?: number[]; // mmol/L
}

export interface EnergySystemContribution {
  aerobic: number; // percentage
  anaerobicAlactic: number; // percentage (phosphocreatine system)
  anaerobicLactic: number; // percentage (glycolytic system)
  totalEnergyExpenditure: number; // kJ
}

export interface TrainingLoad {
  volume: number; // total meters
  intensity: number; // weighted average intensity
  trainingStressScore: number; // TSS-like metric
  monotony: number; // training monotony index
  strain: number; // training strain index
  recoveryTime: number; // estimated recovery time in hours
}