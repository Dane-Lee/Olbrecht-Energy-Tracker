// Database type definitions for Supabase
// This provides type safety for all database operations

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      teams: {
        Row: {
          id: string
          name: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      athletes: {
        Row: {
          id: string
          name: string
          email: string | null
          date_of_birth: string
          gender: 'male' | 'female'
          specialty_distance: number
          specialty_stroke: 'freestyle' | 'backstroke' | 'breaststroke' | 'butterfly' | 'individual-medley'
          specialty_race_type: 'sprint' | 'middle-distance' | 'distance' | 'open-water'
          personal_bests: Json | null
          physiological_profile_id: string | null
          team_id: string | null
          profile_picture: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email?: string | null
          date_of_birth: string
          gender: 'male' | 'female'
          specialty_distance: number
          specialty_stroke: 'freestyle' | 'backstroke' | 'breaststroke' | 'butterfly' | 'individual-medley'
          specialty_race_type: 'sprint' | 'middle-distance' | 'distance' | 'open-water'
          personal_bests?: Json | null
          physiological_profile_id?: string | null
          team_id?: string | null
          profile_picture?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string | null
          date_of_birth?: string
          gender?: 'male' | 'female'
          specialty_distance?: number
          specialty_stroke?: 'freestyle' | 'backstroke' | 'breaststroke' | 'butterfly' | 'individual-medley'
          specialty_race_type?: 'sprint' | 'middle-distance' | 'distance' | 'open-water'
          personal_bests?: Json | null
          physiological_profile_id?: string | null
          team_id?: string | null
          profile_picture?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "athletes_physiological_profile_id_fkey"
            columns: ["physiological_profile_id"]
            isOneToOne: true
            referencedRelation: "physiological_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "athletes_team_id_fkey"
            columns: ["team_id"]
            isOneToOne: false
            referencedRelation: "teams"
            referencedColumns: ["id"]
          }
        ]
      }
      physiological_profiles: {
        Row: {
          id: string
          athlete_id: string | null
          critical_velocity: number
          anaerobic_capacity: number
          aerobic_power: number
          lactate_threshold: number
          max_lactate: number
          recovery_rate: number
          estimated_vo2_max: number | null
          resting_heart_rate: number | null
          max_heart_rate: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          athlete_id?: string | null
          critical_velocity: number
          anaerobic_capacity: number
          aerobic_power: number
          lactate_threshold: number
          max_lactate: number
          recovery_rate: number
          estimated_vo2_max?: number | null
          resting_heart_rate?: number | null
          max_heart_rate?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          athlete_id?: string | null
          critical_velocity?: number
          anaerobic_capacity?: number
          aerobic_power?: number
          lactate_threshold?: number
          max_lactate?: number
          recovery_rate?: number
          estimated_vo2_max?: number | null
          resting_heart_rate?: number | null
          max_heart_rate?: number | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_athlete"
            columns: ["athlete_id"]
            isOneToOne: true
            referencedRelation: "athletes"
            referencedColumns: ["id"]
          }
        ]
      }
      training_sessions: {
        Row: {
          id: string
          athlete_id: string
          date: string
          session_type: 'training' | 'competition' | 'test'
          total_distance: number
          total_time: number
          average_intensity: number
          energy_system_contribution: Json
          training_load: Json
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          athlete_id: string
          date: string
          session_type: 'training' | 'competition' | 'test'
          total_distance: number
          total_time: number
          average_intensity: number
          energy_system_contribution: Json
          training_load: Json
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          athlete_id?: string
          date?: string
          session_type?: 'training' | 'competition' | 'test'
          total_distance?: number
          total_time?: number
          average_intensity?: number
          energy_system_contribution?: Json
          training_load?: Json
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_sessions_athlete_id_fkey"
            columns: ["athlete_id"]
            isOneToOne: false
            referencedRelation: "athletes"
            referencedColumns: ["id"]
          }
        ]
      }
      training_sets: {
        Row: {
          id: string
          session_id: string
          distance: number
          repetitions: number
          times: number[]
          rest_interval: number
          stroke_rate: number[] | null
          heart_rate: number[] | null
          perceived_exertion: number[] | null
          lactate_values: number[] | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          session_id: string
          distance: number
          repetitions: number
          times: number[]
          rest_interval: number
          stroke_rate?: number[] | null
          heart_rate?: number[] | null
          perceived_exertion?: number[] | null
          lactate_values?: number[] | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          session_id?: string
          distance?: number
          repetitions?: number
          times?: number[]
          rest_interval?: number
          stroke_rate?: number[] | null
          heart_rate?: number[] | null
          perceived_exertion?: number[] | null
          lactate_values?: number[] | null
          created_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "training_sets_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "training_sessions"
            referencedColumns: ["id"]
          }
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      gender_enum: 'male' | 'female'
      specialty_stroke_enum: 'freestyle' | 'backstroke' | 'breaststroke' | 'butterfly' | 'individual-medley'
      specialty_race_type_enum: 'sprint' | 'middle-distance' | 'distance' | 'open-water'
      session_type_enum: 'training' | 'competition' | 'test'
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}